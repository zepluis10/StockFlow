import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  Keyboard,
  TouchableWithoutFeedback,
  Alert,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import Constants from 'expo-constants';

const API_BASE_URL = Constants.expoConfig.extra.API_URL;

export default function PasswordRecovery({ navigation }) {
  const [email, setEmail] = useState('');

  const handlePasswordReset = async () => {
    // Validação do formato de email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      Alert.alert('Erro', 'Por favor insira um email válido.');
      return;
    }

    try {
      const response = await fetch(`${API_BASE_URL}/auth/recover-password`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });

      const data = await response.json();

      if (response.ok) {
        Alert.alert('Sucesso', 'Código de recuperação enviado para o email.');
        navigation.navigate('RecoveryCode', { email });
      } else {
        Alert.alert('Erro', data.message || 'Erro ao solicitar recuperação.');
      }
    } catch (err) {
      console.error(err);
      Alert.alert('Erro', 'Erro ao comunicar com o servidor.');
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 100 : 0}
    >
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <View style={styles.inner}>
          <Text style={styles.heading}>Recuperar palavra-passe</Text>
          <Text style={styles.subheading}>
            Insere o teu email e enviaremos um código para definires uma nova palavra-passe.
          </Text>

          <Text style={styles.label}>Insere o teu email</Text>
          <View style={styles.inputContainer}>
            <MaterialIcons name="email" size={20} color="#999" style={styles.icon} />
            <TextInput
              placeholder="Email"
              style={styles.input}
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              autoCapitalize="none"
              textContentType="emailAddress"
              autoComplete="off"
            />
          </View>

          <TouchableOpacity style={styles.button} onPress={handlePasswordReset}>
            <Text style={styles.buttonText}>Enviar</Text>
          </TouchableOpacity>

          <Text style={styles.bottomText}>
            Sabes a palavra-passe?
            <Text style={styles.loginLink} onPress={() => navigation.navigate('Login')}>
              {' '}Inicia sessão
            </Text>
          </Text>
        </View>
      </TouchableWithoutFeedback>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  inner: {
    flex: 1,
    padding: 24,
    justifyContent: 'top',
    paddingVertical: 40,
  },
  heading: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#004d5c',
    textAlign: 'center',
    marginBottom: 10,
  },
  subheading: {
    fontSize: 14,
    color: '#444',
    textAlign: 'center',
    marginBottom: 30,
  },
  label: {
    fontSize: 14,
    color: '#333',
    marginBottom: 6,
    marginLeft: 4,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 12,
    marginBottom: 20,
  },
  icon: {
    marginRight: 8,
  },
  input: {
    flex: 1,
    fontSize: 15,
  },
  button: {
    backgroundColor: '#004d5c',
    paddingVertical: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 20,
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  bottomText: {
    textAlign: 'center',
    fontSize: 14,
    color: '#444',
  },
  loginLink: {
    color: '#004d5c',
    fontWeight: 'bold',
  },
});
