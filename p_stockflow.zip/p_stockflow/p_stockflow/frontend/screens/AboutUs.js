import React from 'react';
import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity } from 'react-native';
import { Feather } from '@expo/vector-icons';

export default function AboutUs({ navigation }) {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Feather name="arrow-left" size={28} color="#004d5c" />
        </TouchableOpacity>
        <Text style={styles.title}>Acerca de Nós</Text>
        <View style={{ width: 28 }} />
      </View>
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.text}>
          Bem-vindo à nossa aplicação de gestão de logística, StockFlow! Somos uma equipa dedicada ao desenvolvimento de soluções tecnológicas inovadoras para otimizar processos empresariais.
        </Text>
        <Text style={styles.sectionTitle}>Missão</Text>
        <Text style={styles.text}>
          A nossa missão é fornecer uma plataforma intuitiva e eficiente para ajudar empresas a gerirem os seus clientes, stocks e encomendas de forma simplificada e organizada.
        </Text>
        <Text style={styles.sectionTitle}>Visão</Text>
        <Text style={styles.text}>
          Queremos ser uma referência no setor de software de gestão logística, oferecendo ferramentas modernas e acessíveis para melhorar a produtividade e a tomada de decisão dos nossos utilizadores.
        </Text>
        <Text style={styles.sectionTitle}>Os Nossos Valores</Text>
        <View style={styles.list}>
          <Text style={styles.listItem}>• Inovação: Utilizamos tecnologias de ponta para criar soluções eficazes.</Text>
          <Text style={styles.listItem}>• Simplicidade: Priorizamos interfaces intuitivas e fáceis de usar.</Text>
          <Text style={styles.listItem}>• Compromisso: Estamos focados na satisfação dos nossos utilizadores.</Text>
          <Text style={styles.listItem}>• Segurança: Garantimos a proteção dos dados e a conformidade com normas de privacidade.</Text>
        </View>
        <Text style={styles.text}>
          Acreditamos que a tecnologia pode transformar a forma como as empresas operam, tornando os processos mais ágeis e eficazes. Obrigado por confiar em nós!
        </Text>
        <Image
          source={require('../assets/Logo.png')}
          style={styles.image}
          resizeMode="contain"
        />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 48,
    paddingBottom: 16,
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  title: { fontSize: 24, fontWeight: 'bold', color: '#222', textAlign: 'center', flex: 1 },
  content: { padding: 20, paddingBottom: 40 },
  text: { fontSize: 16, color: '#222', marginBottom: 16, textAlign: 'justify' },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', color: '#004d5c', marginTop: 10, marginBottom: 4 },
  list: { marginBottom: 16 },
  listItem: { fontSize: 16, color: '#222', marginLeft: 10, marginBottom: 4 },
  image: {
    width: 70,
    height: 70,
    alignSelf: 'center',
    marginTop: 24,
    marginBottom: 10,
    opacity: 0.9
  },
});