import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import Constants from 'expo-constants';

const API_BASE_URL = Constants.expoConfig.extra.API_URL;

export default function RecoveryCodeScreen({ navigation, route }) {
  const [code, setCode] = useState('');
  const [email, setEmail] = useState(route.params?.email || '');

  const isRegister = route.params?.isRegister;
  const nome = route.params?.nome;
  const password = route.params?.password;
  const contacto = route.params?.contacto;

  const handleValidateCode = async () => {
    if (isRegister) {
      try {
        const response = await fetch(`${API_BASE_URL}/auth/register`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            nome,
            email,
            password,
            contacto,
            code,
          }),
        });
        const data = await response.json();

        if (response.ok) {
          Alert.alert('Sucesso', data.message || 'Registo realizado com sucesso!');
          navigation.navigate('Login');
        } else {
          Alert.alert('Erro', data.message || 'Código inválido ou expirado.');
        }
      } catch (err) {
        Alert.alert('Erro', 'Erro ao validar código.');
      }
    } else {
      try {
        const response = await fetch(`${API_BASE_URL}/auth/validate-recovery-code`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, code }),
        });
        const data = await response.json();

        if (response.ok) {
          navigation.navigate('NovaPassword', { email, code });
        } else {
          Alert.alert('Erro', data.message || 'Código inválido ou expirado.');
        }
      } catch (err) {
        Alert.alert('Erro', 'Erro ao validar código.');
      }
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <Text style={styles.title}>Verificação de Código</Text>
      <Text style={styles.subtitle}>Insere o código que recebeste no email.</Text>
      <TextInput
        style={styles.input}
        placeholder="Código de recuperação"
        value={code}
        onChangeText={setCode}
        keyboardType="numeric"
        maxLength={6}
      />
      <TouchableOpacity style={styles.button} onPress={handleValidateCode}>
        <Text style={styles.buttonText}>Validar Código</Text>
      </TouchableOpacity>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-start',
    paddingTop: '10%',
    alignItems: 'center',
    padding: 24,
    backgroundColor: '#fff'
  },

  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#004d5c',
    marginBottom: 10
  },

  subtitle: {
    fontSize: 16,
    color: '#555',
    marginBottom: 20
  },

  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    padding: 12,
    width: '100%',
    marginBottom: 20,
    fontSize: 16
  },
  button: {
    backgroundColor: '#004d5c',
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
    width: '100%'
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16
  },
});