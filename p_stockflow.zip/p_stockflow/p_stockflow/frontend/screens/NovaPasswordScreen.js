import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Constants from 'expo-constants';

const API_BASE_URL = Constants.expoConfig.extra.API_URL;

export default function NovaPasswordScreen({ navigation, route }) {
  const [password, setPassword] = useState('');
  const [confirmarPassword, setConfirmarPassword] = useState('');
  const email = route.params?.email;
  const code = route.params?.code;
  const isRecovery = !!email && !!code;

  const handleChangePassword = async () => {
    if (!password || !confirmarPassword) {
      Alert.alert('Erro', 'Preenche ambos os campos.');
      return;
    }
    if (password !== confirmarPassword) {
      Alert.alert('Erro', 'As palavras-passe não coincidem.');
      return;
    }
    try {
      let response;
      if (isRecovery) {

        response = await fetch(`${API_BASE_URL}/auth/change-password`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ email, code, password }),
        });
      } else {

        const token = await AsyncStorage.getItem('token');
        response = await fetch(`${API_BASE_URL}/profile/password`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
          },
          body: JSON.stringify({ password }),
        });
      }

      const data = await response.json();
      if (response.ok) {
        Alert.alert('Sucesso', 'Palavra-passe alterada com sucesso!', [
          { text: 'OK', onPress: () => navigation.navigate('Login') }
        ]);
      } else {
        Alert.alert('Erro', data.message || 'Erro ao alterar a palavra-passe.');
      }
    } catch (err) {
      Alert.alert('Erro', 'Erro ao comunicar com o servidor.');
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <Text style={styles.title}>Nova Palavra-passe</Text>
      <Text style={styles.subtitle}>Define a tua nova palavra-passe.</Text>
      <TextInput
        style={styles.input}
        placeholder="Nova palavra-passe"
        secureTextEntry
        value={password}
        onChangeText={setPassword}
      />
      <TextInput
        style={styles.input}
        placeholder="Confirmar palavra-passe"
        secureTextEntry
        value={confirmarPassword}
        onChangeText={setConfirmarPassword}
      />
      <TouchableOpacity style={styles.button} onPress={handleChangePassword}>
        <Text style={styles.buttonText}>Alterar Palavra-passe</Text>
      </TouchableOpacity>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'top',
    paddingTop: '10%',
    alignItems: 'center',
    padding: 24,
    backgroundColor: '#fff'
  },

  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#004d5c',
    marginBottom: 10
  },

  subtitle: {
    fontSize: 16,
    color: '#555',
    marginBottom: 20
  },

  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    padding: 12,
    width: '100%',
    marginBottom: 20,
    fontSize: 16
  },

  button: {
    backgroundColor: '#004d5c',
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
    width: '100%'
  },

  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16
  },
});

