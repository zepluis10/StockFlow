import React, { useEffect, useState, useCallback } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, Image, ActivityIndicator } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Navbar from '../components/navbar';
import { useFocusEffect, useRoute } from '@react-navigation/native';
import * as ImagePicker from 'expo-image-picker';
import Constants from 'expo-constants';

const API_BASE_URL = Constants.expoConfig?.extra?.API_URL || 'http://localhost:3001';

export default function Definicoes({ navigation }) {
  const [user, setUser] = useState(null);
  const [image, setImage] = useState(null);
  const route = useRoute();

  const carregarPerfil = async () => {
    const userStr = await AsyncStorage.getItem('user');
    if (userStr) setUser(JSON.parse(userStr));

    const token = await AsyncStorage.getItem('token');
    if (!token) {
      Alert.alert('Erro', 'Sessão expirada. Faz login novamente.');
      navigation.navigate('Login');
      return;
    }
    try {
      const response = await fetch(`${API_BASE_URL}/profile`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await response.json();
      if (response.ok) {
        setUser(data.user);
        await AsyncStorage.setItem('user', JSON.stringify(data.user));
      } else {
        Alert.alert('Erro', 'Token inválido ou expirado.');
        navigation.navigate('Login');
      }
    } catch (error) {
      Alert.alert('Erro', 'Falha ao carregar perfil.');
    }
  };

  useFocusEffect(
    useCallback(() => {
      carregarPerfil();
    }, [route.params?.refresh])
  );

  const handleLogout = async () => {
    await AsyncStorage.removeItem('token');
    Alert.alert('Terminar Sessão', 'Tens a certeza que queres terminar a sessão?', [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Sim', onPress: () => navigation.navigate('Login') },
    ]);
  };

  const handleDeleteAccount = async () => {
    Alert.alert('Apagar Conta', 'Tens a certeza que queres apagar a tua conta?', [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Sim', onPress: async () => {
          try {
            const token = await AsyncStorage.getItem('token');
            await fetch(`${API_BASE_URL}/profile`, {
              method: 'DELETE',
              headers: { Authorization: `Bearer ${token}` },
            });
            await AsyncStorage.removeItem('token');
            Alert.alert('Conta apagada.');
            navigation.navigate('WelcomeScreen');
          } catch (error) {
            Alert.alert('Erro', 'Não foi possível apagar a conta.');
          }
        }
      },
    ]);
  };

  const handleImagePicker = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permissão necessária', 'É necessário permitir acesso à galeria para alterar a foto.');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.7,
    });
    if (!result.canceled) {
      const token = await AsyncStorage.getItem('token');
      const formData = new FormData();
      formData.append('avatar', {
        uri: result.assets[0].uri,
        name: 'avatar.jpg',
        type: 'image/jpeg',
      });
      try {
        const uploadRes = await fetch(`${API_BASE_URL}/profile/avatar`, {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'multipart/form-data',
          },
          body: formData,
        });
        const uploadData = await uploadRes.json();
        if (uploadRes.ok) {
          const userStr = await AsyncStorage.getItem('user');
          if (userStr) {
            const user = JSON.parse(userStr);
            user.avatarUrl = uploadData.avatarUrl;
            await AsyncStorage.setItem('user', JSON.stringify(user));
          }
          carregarPerfil();
        } else {
          Alert.alert('Erro', 'Falha ao fazer upload do avatar.');
        }
      } catch (e) {
        Alert.alert('Erro', 'Erro ao enviar avatar.');
      }
    }
  };

  if (!user) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#004d5c" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Definições</Text>
      <View style={styles.profileHeader}>
        <TouchableOpacity onPress={handleImagePicker}>
          <Image
            source={user?.avatarUrl ? { uri: user.avatarUrl } : require('../assets/avatar.png')}
            style={styles.avatar}
          />
        </TouchableOpacity>
        <Text style={styles.name}>{user.nome}</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Conta</Text>
        <TouchableOpacity style={styles.option} onPress={() => navigation.navigate('EditProfile')}>
          <Text style={styles.optionText}>Editar Perfil</Text>
          <Text style={styles.arrow}>&gt;</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.option} onPress={() => navigation.navigate('NovaPassword')}>
          <Text style={styles.optionText}>Alterar palavra-passe</Text>
          <Text style={styles.arrow}>&gt;</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Informações</Text>
        <TouchableOpacity style={styles.option} onPress={() => navigation.navigate('AboutUs')}>
          <Text style={styles.optionText}>Acerca de nós</Text>
          <Text style={styles.arrow}>&gt;</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.option} onPress={() => navigation.navigate('PrivacyPolicy')}>
          <Text style={styles.optionText}>Política de privacidade</Text>
          <Text style={styles.arrow}>&gt;</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.option} onPress={() => navigation.navigate('Terms')}>
          <Text style={styles.optionText}>Termos e condições</Text>
          <Text style={styles.arrow}>&gt;</Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity style={[styles.button, { backgroundColor: '#004d5c' }]} onPress={handleLogout}>
        <Text style={styles.buttonText}>Terminar Sessão</Text>
      </TouchableOpacity>

      <TouchableOpacity style={[styles.button, { backgroundColor: '#8b0000', marginTop: 12 }]} onPress={handleDeleteAccount}>
        <Text style={styles.buttonText}>Apagar Conta</Text>
      </TouchableOpacity>

      <Navbar />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 24,
    paddingTop: 24,
    paddingBottom: 80,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#000',
    marginBottom: 0,
  },
  profileHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 24,
    marginTop: 36,
  },
  avatar: { width: 40, height: 40, borderRadius: 20, marginRight: 10 },
  name: { fontSize: 18, fontWeight: 'bold', color: '#004d5c' },
  section: { marginBottom: 32 },
  sectionTitle: { fontSize: 14, color: '#888', marginBottom: 12 },
  option: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  optionText: { fontSize: 16, color: '#000' },
  arrow: { fontSize: 18, color: '#ccc' },
  button: {
    paddingVertical: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 8,
  },
  buttonText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
});
