import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image, TextInput, Alert, ActivityIndicator, KeyboardAvoidingView, Platform, TouchableWithoutFeedback, Keyboard } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as ImagePicker from 'expo-image-picker';
import { Feather } from '@expo/vector-icons';
import Constants from 'expo-constants';

const API_BASE_URL = Constants.expoConfig.extra.API_URL;

export default function EditProfile({ navigation }) {
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [contacto, setContacto] = useState('');
  const [avatar, setAvatar] = useState(null);
  const [avatarError, setAvatarError] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const fetchProfile = async () => {
      const token = await AsyncStorage.getItem('token');
      try {
        const response = await fetch(`${API_BASE_URL}/profile`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        const data = await response.json();
        if (response.ok) {
          setNome(data.user.nome);
          setEmail(data.user.email);
          setContacto(data.user.contacto || '');
          setAvatar(data.user.avatarUrl || null);
        } else {
          Alert.alert('Erro', 'Não foi possível carregar o perfil.');
          navigation.goBack();
        }
      } catch (error) {
        Alert.alert('Erro', 'Falha ao carregar perfil.');
        navigation.goBack();
      }
      setLoading(false);
    };
    fetchProfile();
  }, []);

  const pickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permissão necessária', 'É necessário permitir acesso à galeria para alterar a foto.');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.7,
    });
    if (!result.canceled) {
      const token = await AsyncStorage.getItem('token');
      console.log('Token:', token ? 'Existe' : 'Não existe');
      console.log('URI da imagem:', result.assets[0].uri);

      const formData = new FormData();
      formData.append('avatar', {
        uri: result.assets[0].uri,
        name: 'avatar.jpg',
        type: 'image/jpeg',
      });

      console.log('FormData criado, enviando...');

      try {
        const uploadRes = await fetch(`${API_BASE_URL}/profile/avatar`, {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${token}`,
          },
          body: formData,
        });

        console.log('Status da resposta:', uploadRes.status);
        console.log('Headers da resposta:', uploadRes.headers);

        const uploadData = await uploadRes.json();
        console.log('Dados da resposta:', uploadData);

        if (uploadRes.ok) {
          setAvatar(uploadData.avatarUrl);
          setAvatarError(false);
          const userStr = await AsyncStorage.getItem('user');
          if (userStr) {
            const user = JSON.parse(userStr);
            user.avatarUrl = uploadData.avatarUrl;
            await AsyncStorage.setItem('user', JSON.stringify(user));
          }
          Alert.alert('Sucesso', 'Avatar atualizado com sucesso!');
        } else {
          console.error('Erro upload:', uploadData);
          Alert.alert('Erro', uploadData.message || 'Falha ao fazer upload do avatar.');
        }
      } catch (e) {
        console.error('Erro ao enviar avatar:', e);
        Alert.alert('Erro', 'Erro ao enviar avatar: ' + e.message);
      }
    }
  };

  const handleSave = async () => {
    setSaving(true);
    const token = await AsyncStorage.getItem('token');
    try {
      const res = await fetch(`${API_BASE_URL}/profile`, {
        method: 'PUT',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ nome, email, contacto, avatarUrl: avatar }),
      });
      const data = await res.json();
      if (res.ok) {
        const profileRes = await fetch(`${API_BASE_URL}/profile`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        const profileData = await profileRes.json();
        await AsyncStorage.setItem('user', JSON.stringify(profileData.user));
        Alert.alert('Sucesso', 'Perfil atualizado com sucesso!', [
          { text: 'OK', onPress: () => navigation.goBack() },
        ]);
      } else {
        Alert.alert('Erro', data.message || 'Não foi possível atualizar o perfil.');
      }
    } catch (e) {
      Alert.alert('Erro', 'Erro ao atualizar perfil.');
    }
    setSaving(false);
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#004d5c" />
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <View style={styles.container}>
          <TouchableOpacity style={styles.avatarContainer} onPress={pickImage}>
            <Image
              source={avatar && !avatarError ? { uri: avatar } : require('../assets/avatar.png')}
              style={styles.avatar}
              onError={() => setAvatarError(true)}
            />
          </TouchableOpacity>
          <TouchableOpacity style={styles.alterarBtn} onPress={pickImage}>
            <Text style={styles.alterarBtnText}>Alterar</Text>
          </TouchableOpacity>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Nome Completo</Text>
            <View style={styles.inputWrapper}>
              <Feather name="user" size={18} color="#888" style={styles.icon} />
              <TextInput
                style={styles.input}
                value={nome}
                onChangeText={setNome}
                placeholder="Nome Completo"
              />
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Contacto</Text>
            <View style={styles.inputWrapper}>
              <Feather name="phone" size={18} color="#888" style={styles.icon} />
              <TextInput
                style={styles.input}
                value={contacto}
                onChangeText={setContacto}
                placeholder="Contacto"
                keyboardType="phone-pad"
              />
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Email</Text>
            <View style={styles.inputWrapper}>
              <Feather name="mail" size={18} color="#888" style={styles.icon} />
              <TextInput
                style={styles.input}
                value={email}
                onChangeText={setEmail}
                placeholder="Email"
                keyboardType="email-address"
                autoCapitalize="none"
              />
            </View>
          </View>

          <TouchableOpacity
            style={styles.saveBtn}
            onPress={handleSave}
            disabled={saving}
          >
            <Text style={styles.saveBtnText}>{saving ? 'A guardar...' : 'Salvar e sair'}</Text>
          </TouchableOpacity>
        </View>
      </TouchableWithoutFeedback>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', padding: 24 },
  avatarContainer: { alignItems: 'center', marginTop: 16 },
  avatar: { width: 90, height: 90, borderRadius: 45, backgroundColor: '#eee' },
  alterarBtn: {
    alignSelf: 'center',
    backgroundColor: '#004d5c',
    paddingVertical: 8,
    paddingHorizontal: 32,
    borderRadius: 6,
    marginTop: 10,
    marginBottom: 24,
  },
  alterarBtnText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  inputGroup: { marginBottom: 18 },
  label: { marginBottom: 6, color: '#888', fontSize: 14 },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f6f6f6',
    borderRadius: 8,
    paddingHorizontal: 10,
    borderWidth: 1,
    borderColor: '#eee',
  },
  icon: { marginRight: 8 },
  input: { flex: 1, height: 44, fontSize: 16, color: '#222' },
  saveBtn: {
    backgroundColor: '#004d5c',
    paddingVertical: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 32,
  },
  saveBtnText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
});