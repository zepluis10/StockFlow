import React from 'react';
import { Text, StyleSheet, Image, TouchableOpacity, StatusBar, Dimensions, SafeAreaView, } from 'react-native';

const { width, height } = Dimensions.get('window');

export default function WelcomeScreen({ navigation }) {
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" />

      <Text style={styles.title}>StockFlow</Text>
      <Text style={styles.subtitle}>A tua aplicação de gestão de logística!</Text>

      <Image
        source={require('../assets/Logo.png')}
        style={styles.logo}
        resizeMode="contain"
      />

      <TouchableOpacity
        style={styles.registerButton}
        onPress={() => navigation.navigate('Registo')}
      >
        <Text style={styles.registerText}>Registar-se</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.loginButton}
        onPress={() => navigation.navigate('Login')}
      >
        <Text style={styles.loginText}>Iniciar sessão</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: '8%',
  },
  title: {
    fontSize: width * 0.08,
    fontWeight: 'bold',
    color: '#004d5c',
    marginBottom: 8,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: width * 0.04,
    color: '#333',
    marginBottom: 30,
    textAlign: 'center',
  },
  logo: {
    width: width * 0.4,
    height: width * 0.4,
    marginBottom: height * 0.05,
  },
  registerButton: {
    backgroundColor: '#004d5c',
    paddingVertical: height * 0.018,
    paddingHorizontal: width * 0.2,
    borderRadius: 8,
    marginBottom: 16,
  },
  registerText: {
    color: '#fff',
    fontSize: width * 0.045,
    fontWeight: 'bold',
  },
  loginButton: {
    borderColor: '#004d5c',
    borderWidth: 2,
    paddingVertical: height * 0.018,
    paddingHorizontal: width * 0.18,
    borderRadius: 8,
  },
  loginText: {
    color: '#004d5c',
    fontSize: width * 0.045,
    fontWeight: 'bold',
  },
});
