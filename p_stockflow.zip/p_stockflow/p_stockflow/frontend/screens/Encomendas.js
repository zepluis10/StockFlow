import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, Dimensions, ActivityIndicator, Alert, FlatList, TextInput, Keyboard, TouchableWithoutFeedback } from 'react-native';
import { Feather } from '@expo/vector-icons';
import Navbar from '../components/navbar';
import AsyncStorage from '@react-native-async-storage/async-storage';
import AddEncomendaModal from '../components/AddEncomendaModal';
import { Picker } from '@react-native-picker/picker';
import { Swipeable } from 'react-native-gesture-handler';
import Constants from 'expo-constants';

const { width } = Dimensions.get('window');
const API_BASE_URL = Constants.expoConfig.extra.API_URL;

export default function Encomendas() {
  const [user, setUser] = useState(null);
  const [clientes, setClientes] = useState([]);
  const [items, setItems] = useState([]);
  const [encomendas, setEncomendas] = useState([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [editEncomenda, setEditEncomenda] = useState(null);

  const [searchText, setSearchText] = useState('');
  const [showSearch, setShowSearch] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [selectedProduto, setSelectedProduto] = useState('');
  const [precoMax, setPrecoMax] = useState('');

  useEffect(() => {
    const carregarPerfil = async () => {
      const token = await AsyncStorage.getItem('token');
      if (!token) {
        Alert.alert('Erro', 'Sessão expirada. Faz login novamente.');
        return;
      }
      try {
        const response = await fetch(`${API_BASE_URL}/profile`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        const data = await response.json();
        if (response.ok) setUser(data.user);
      } catch (error) { }
    };
    carregarPerfil();
  }, []);

  const fetchAll = async () => {
    const token = await AsyncStorage.getItem('token');
    try {
      const [cRes, iRes, eRes] = await Promise.all([
        fetch(`${API_BASE_URL}/clientes`, { headers: { Authorization: `Bearer ${token}` } }),
        fetch(`${API_BASE_URL}/items`, { headers: { Authorization: `Bearer ${token}` } }),
        fetch(`${API_BASE_URL}/encomendas`, { headers: { Authorization: `Bearer ${token}` } }),
      ]);
      setClientes(await cRes.json());
      setItems(await iRes.json());
      setEncomendas(await eRes.json());
    } catch (err) { }
  };

  useEffect(() => {
    if (user) fetchAll();
  }, [user]);

  const handleEncomendaAdded = () => {
    fetchAll();
    setModalVisible(false);
  };

  const produtosUnicos = [
    ...new Set(
      encomendas.map((e) => (e.item ? e.item.nome : e.itemNome))
    ),
  ];
  const filteredEncomendas = encomendas.filter((encomenda) => {
    const nomeProduto = encomenda.item ? encomenda.item.nome : encomenda.itemNome;
    const precoUnitario = encomenda.item ? encomenda.item.preco : encomenda.itemPreco;
    const matchCliente = encomenda.cliente.nome.toLowerCase().includes(searchText.toLowerCase());
    const matchProduto = selectedProduto === '' || nomeProduto === selectedProduto;
    const precoTotal = precoUnitario * encomenda.quantidade;
    const matchPreco = precoMax === '' || precoTotal <= parseFloat(precoMax);
    return matchCliente && matchProduto && matchPreco;
  });

  const renderRightActions = (encomendaId, item) => (
    <View style={{ flexDirection: 'row', paddingRight: 8 }}>
      <TouchableOpacity
        style={[styles.editButton, { marginRight: 4 }]}
        onPress={() => {
          setEditEncomenda(item);
          setModalVisible(true);
        }}
      >
        <Feather name="edit-2" size={24} color="#fff" />
      </TouchableOpacity>
      <TouchableOpacity style={styles.deleteButton} onPress={() => confirmDelete(encomendaId)}>
        <Feather name="trash-2" size={24} color="#fff" />
      </TouchableOpacity>
    </View>
  );

  const renderEncomenda = ({ item }) => {
    const nomeProduto = item.item ? item.item.nome : item.itemNome;
    const precoUnitario = item.item ? item.item.preco : item.itemPreco;
    const precoTotal = precoUnitario * item.quantidade;
    return (
      <Swipeable renderRightActions={() => renderRightActions(item.id, item)}>
        <View style={styles.encomendaCard}>
          <View>
            <Text style={styles.encomendaId}>#{item.id}</Text>
            <Text style={styles.encomendaCliente}>{item.cliente.nome}</Text>
            <Text style={styles.encomendaProduto}>{nomeProduto}</Text>
          </View>
          <View style={{ alignItems: 'flex-end' }}>
            <Text style={styles.encomendaQtd}>Qtd: {item.quantidade}</Text>
            <Text style={styles.encomendaPreco}>
              {precoTotal.toLocaleString('pt-PT', { style: 'currency', currency: 'EUR' })}
            </Text>
          </View>
        </View>
      </Swipeable>
    );
  };

  const handleDeleteEncomenda = async (encomendaId) => {
    const token = await AsyncStorage.getItem('token');
    try {
      const res = await fetch(`${API_BASE_URL}/encomendas/${encomendaId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        fetchAll();
      } else {
        Alert.alert('Erro', 'Erro ao apagar encomenda.');
      }
    } catch (err) {
      Alert.alert('Erro', 'Erro ao comunicar com o servidor.');
    }
  };

  const confirmDelete = (encomendaId) => {
    Alert.alert('Apagar Encomenda', 'Tens a certeza que queres apagar esta encomenda?', [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Sim', onPress: () => handleDeleteEncomenda(encomendaId) },
    ]);
  };

  if (!user) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#004d5c" />
      </View>
    );
  }

  return (
    <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.title}>Encomendas</Text>
          <View style={styles.icons}>
            <TouchableOpacity style={styles.iconButton} onPress={() => setShowSearch(!showSearch)}>
              <Feather name="search" size={24} color="#000" />
            </TouchableOpacity>
            <TouchableOpacity style={styles.iconButton} onPress={() => setShowFilters(!showFilters)}>
              <Feather name="filter" size={24} color="#000" />
            </TouchableOpacity>
          </View>
        </View>

        {/* Barra de pesquisa */}
        {showSearch && (
          <TextInput
            placeholder="Pesquisar por cliente..."
            value={searchText}
            onChangeText={setSearchText}
            style={styles.input}
          />
        )}

        {/* Filtros */}
        {showFilters && (
          <View>
            <Picker
              selectedValue={selectedProduto}
              onValueChange={setSelectedProduto}
              style={styles.input}
            >
              <Picker.Item label="Todos os produtos" value="" />
              {produtosUnicos.map((nome, idx) => (
                <Picker.Item key={idx} label={nome} value={nome} />
              ))}
            </Picker>
            <TextInput
              placeholder="Preço máximo (€)"
              value={precoMax}
              onChangeText={setPrecoMax}
              keyboardType="numeric"
              style={styles.input}
            />
          </View>
        )}

        <View style={{ flex: 1 }}>
          {filteredEncomendas.length === 0 ? (
            <View style={styles.emptyContainer}>
              <Image
                source={require('../assets/encomendasvazio.png')}
                style={styles.image}
                resizeMode="contain"
              />
              <Text style={styles.emptyText}>Está vazio!</Text>
            </View>
          ) : (
            <FlatList
              data={filteredEncomendas}
              keyExtractor={(item) => item.id.toString()}
              renderItem={renderEncomenda}
              contentContainerStyle={{ paddingBottom: 120 }}
              showsVerticalScrollIndicator={true}
            />
          )}
        </View>

        <TouchableOpacity
          style={styles.floatingButton}
          onPress={() => {
            setEditEncomenda(null);
          }}
        >
          <Feather name="plus" size={28} color="#fff" />
        </TouchableOpacity>
        <AddEncomendaModal
          visible={modalVisible}
          onClose={() => {
            setModalVisible(false);
            setEditEncomenda(null);
          }}
          clientes={clientes}
          items={items}
          onEncomendaAdded={handleEncomendaAdded}
          encomendaParaEditar={editEncomenda}
        />
        <Navbar />
      </View>
    </TouchableWithoutFeedback>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, paddingTop: 24, paddingBottom: 80, backgroundColor: '#fff' },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingBottom: 24,
    paddingHorizontal: 24,
  },
  title: { fontSize: 28, fontWeight: 'bold', color: '#000' },
  icons: { flexDirection: 'row' },
  iconButton: { marginLeft: 20 },
  encomendaCard: {
    backgroundColor: '#f2f2f2',
    borderRadius: 10,
    padding: 16,
    marginBottom: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginHorizontal: 24,
  },
  encomendaId: { fontSize: 14, color: '#888' },
  encomendaCliente: { fontSize: 18, fontWeight: 'bold', color: '#000' },
  encomendaProduto: { fontSize: 16, color: '#555' },
  encomendaQtd: { fontSize: 14, color: '#555' },
  encomendaPreco: { fontSize: 16, fontWeight: 'bold', color: '#004d5c' },
  emptyContainer: { flex: 1, justifyContent: 'flex-start', alignItems: 'center', paddingTop: 150 },
  image: { width: width * 0.4, height: width * 0.4, marginBottom: 20, opacity: 0.7 },
  emptyText: { fontSize: 18, color: '#444' },
  floatingButton: {
    position: 'absolute',
    bottom: 70,
    right: 24,
    backgroundColor: '#004d5c',
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 5,
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowOffset: { width: 0, height: 3 },
    shadowRadius: 4,
    zIndex: 20,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 16,
    marginBottom: 12,
    marginHorizontal: 24,
  },
  editButton: {
    backgroundColor: '#007bff',
    width: 70,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  deleteButton: {
    backgroundColor: '#dc3545',
    width: 70,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
    marginRight: 16,
  },
});
