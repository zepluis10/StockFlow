import React, { useEffect, useState, useCallback } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, Alert, Image } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Navbar from '../components/navbar';
import { useFocusEffect, useRoute } from '@react-navigation/native';
import Constants from 'expo-constants';

const CARD_HEIGHT = 120;
const API_BASE_URL = Constants.expoConfig.extra.API_URL;

export default function Sumario({ navigation }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalItems: 0,
    totalItemsValue: 0,
    totalOrders: 0,
    totalOrdersValue: 0,
    totalClients: 0,
    totalLocations: 0,
  });
  const route = useRoute();

  const carregarDados = async () => {
    setLoading(true);
    const userStr = await AsyncStorage.getItem('user');
    if (userStr) {
      setUser(JSON.parse(userStr));
    }
    const token = await AsyncStorage.getItem('token');
    if (!token) {
      Alert.alert('Erro', 'Sessão expirada. Faz login novamente.');
      return;
    }
    try {
      const profileRes = await fetch(`${API_BASE_URL}/profile`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const profileData = await profileRes.json();
      setUser(profileData.user);

      const [itemsRes, encomendasRes, clientesRes] = await Promise.all([
        fetch(`${API_BASE_URL}/items`, { headers: { Authorization: `Bearer ${token}` } }),
        fetch(`${API_BASE_URL}/encomendas`, { headers: { Authorization: `Bearer ${token}` } }),
        fetch(`${API_BASE_URL}/clientes`, { headers: { Authorization: `Bearer ${token}` } }),
      ]);
      const items = await itemsRes.json();
      const encomendas = await encomendasRes.json();
      const clientes = await clientesRes.json();

      // Calcular totais de items
      const totalItems = items.reduce((acc, item) => acc + (item.quantidade || 0), 0);
      const totalItemsValue = items.reduce((acc, item) => acc + ((item.preco || 0) * (item.quantidade || 0)), 0);

      // Calcular totais de encomendas
      const totalOrders = encomendas.length;
      const totalOrdersValue = encomendas.reduce((acc, enc) => {
        const precoUnitario = enc.item ? enc.item.preco : enc.itemPreco;
        return acc + ((precoUnitario || 0) * (enc.quantidade || 0));
      }, 0);

      // Calcular totais de clientes e localidades
      const totalClients = clientes.length;
      const localidades = [...new Set(clientes.map(c => c.localidade))];
      const totalLocations = localidades.length;

      setStats({
        totalItems,
        totalItemsValue,
        totalOrders,
        totalOrdersValue,
        totalClients,
        totalLocations,
      });
    } catch (error) {
      Alert.alert('Erro', 'Falha ao carregar dados.');
    } finally {
      setLoading(false);
    }
  };

  useFocusEffect(
    useCallback(() => {
      carregarDados();
    }, [route.params?.refresh])
  );

  if (loading) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#004d5c" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Header com avatar e nome */}
      <View style={styles.headerRow}>
        <Image
          source={user?.avatarUrl ? { uri: user.avatarUrl } : require('../assets/avatar.png')}
          style={styles.avatar}
        />
        <Text style={styles.hello}>
          Olá, <Text style={styles.bold}>{user?.nome}</Text> 👋
        </Text>
      </View>
      <Text style={styles.sumario}>Sumário</Text>


      <View style={styles.cardsWrapper}>
        <View style={[styles.card, styles.cardInventario]}>
          <Text style={styles.cardTitle}>Inventário</Text>
          <Text style={styles.cardValue}><Text style={styles.bold}>{stats.totalItems} items.</Text></Text>
          <Text style={styles.cardLabel}>Valor Total</Text>
          <Text style={styles.cardValueBig}>{stats.totalItemsValue.toLocaleString('pt-PT', { style: 'currency', currency: 'EUR' })}</Text>
        </View>
        <View style={[styles.card, styles.cardEncomendas]}>
          <Text style={styles.cardTitle}>Encomendas</Text>
          <Text style={styles.cardValue}>{stats.totalOrders}</Text>
          <Text style={styles.cardLabel}>Valor Total</Text>
          <Text style={styles.cardValueBig}>{stats.totalOrdersValue.toLocaleString('pt-PT', { style: 'currency', currency: 'EUR' })}</Text>
        </View>
        <View style={[styles.card, styles.cardClientes]}>
          <Text style={styles.cardTitle}>Clientes</Text>
          <Text style={styles.cardValue}>{stats.totalClients}</Text>
          <Text style={styles.cardTitle}>Localidades</Text>
          <Text style={styles.cardValue}>{stats.totalLocations}</Text>
        </View>
      </View>

      <Navbar />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 24,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'flex-start',
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'stretch',
    paddingHorizontal: 24,
    marginBottom: 8,
    marginTop: 0,
  },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    marginRight: 12,
  },
  hello: {
    fontSize: 18,
    color: '#222',
    fontWeight: 'bold',
  },
  bold: {
    fontWeight: 'bold',
  },
  sumario: {
    fontSize: 32,
    fontStyle: 'italic',
    alignSelf: 'center',
    marginBottom: 45,
    color: '#222',
  },
  cardsWrapper: {
    width: '100%',
    alignItems: 'center',
    justifyContent: 'flex-start',
    flexGrow: 0,
    flexShrink: 0,
    flexBasis: 'auto',
    marginTop: 0,
  },
  card: {
    borderRadius: 20,
    padding: 18,
    width: '90%',
    height: 150,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
    justifyContent: 'center',
  },
  cardInventario: {
    backgroundColor: '#176B87',
  },
  cardEncomendas: {
    backgroundColor: '#21829A',
  },
  cardClientes: {
    backgroundColor: '#7BB2C2',
  },
  cardTitle: {
    color: '#fff',
    fontSize: 16,
    marginBottom: 4,
  },
  cardValue: {
    color: '#fff',
    fontSize: 22,
    fontWeight: 'bold',
  },
  cardLabel: {
    color: '#fff',
    fontSize: 14,
    marginTop: 8,
  },
  cardValueBig: {
    color: '#fff',
    fontSize: 26,
    fontWeight: 'bold',
  },
});
