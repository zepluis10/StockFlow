import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image } from 'react-native';
import { Feather } from '@expo/vector-icons';

export default function Terms({ navigation }) {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Feather name="arrow-left" size={28} color="#004d5c" />
        </TouchableOpacity>
        <Text style={styles.title}>Termos e Condições</Text>
        <View style={{ width: 28 }} />
      </View>
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.paragraph}>
          <Text style={styles.number}>1. </Text>
          <Text style={styles.bold}>Introdução</Text> {"\n"}
          Estes Termos e Condições regulam o uso da aplicação de gestão de logística. Ao utilizar a aplicação, o utilizador concorda com os termos estabelecidos neste documento.
        </Text>

        <Text style={styles.paragraph}>
          <Text style={styles.number}>2. </Text>
          <Text style={styles.bold}>Uso da Aplicação</Text> {"\n"}
          • A aplicação destina-se à gestão de clientes, stock de produtos e encomendas.{"\n"}
          • O utilizador é responsável pela veracidade das informações inseridas na aplicação.{"\n"}
          • O uso indevido da aplicação, incluindo tentativas de acesso não autorizado, pode resultar na suspensão ou bloqueio da conta.
        </Text>

        <Text style={styles.paragraph}>
          <Text style={styles.number}>3. </Text>
          <Text style={styles.bold}>Registo e Conta do Utilizador</Text> {"\n"}
          • O utilizador pode necessitar de um registo para utilizar certas funcionalidades.{"\n"}
          • É de responsabilidade do utilizador manter a segurança das suas credenciais de acesso.{"\n"}
          • A conta do utilizador é pessoal e intransmissível.
        </Text>

        <Text style={styles.paragraph}>
          <Text style={styles.number}>4. </Text>
          <Text style={styles.bold}>Privacidade e Proteção de Dados</Text> {"\n"}
          • O tratamento de dados pessoais segue a nossa Política de Privacidade.{"\n"}
          • O utilizador concorda que certas informações podem ser armazenadas para o funcionamento da aplicação.
        </Text>

        <Text style={styles.paragraph}>
          <Text style={styles.number}>5. </Text>
          <Text style={styles.bold}>Responsabilidades</Text> {"\n"}
          • A aplicação não se responsabiliza por perdas ou danos resultantes do uso indevido da plataforma.{"\n"}
          • O utilizador é responsável por garantir que as informações inseridas são corretas e atualizadas.
        </Text>

        <Text style={styles.paragraph}>
          <Text style={styles.number}>6. </Text>
          <Text style={styles.bold}>Modificações e Encerramento</Text> {"\n"}
          • Podemos modificar ou encerrar funcionalidades da aplicação sem aviso prévio.{"\n"}
          • O utilizador será notificado de alterações significativas nos Termos e Condições.
        </Text>

        <Text style={styles.paragraph}>
          <Text style={styles.number}>7. </Text>
          <Text style={styles.bold}>Lei Aplicável</Text> {"\n"}
          Estes Termos e Condições são regidos pela legislação aplicável no país onde a empresa está registada.
        </Text>

        <Text style={styles.paragraph}>
          <Text style={styles.number}>8. </Text>
          <Text style={styles.bold}>Contacto</Text> {"\n"}
          Para dúvidas ou esclarecimentos sobre estes Termos e Condições, entre em contacto com a nossa equipa através do suporte da aplicação.
        </Text>

        <Image
          source={require('../assets/Logo.png')}
          style={styles.logo}
          resizeMode="contain"
        />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 48,
    paddingBottom: 16,
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  title: { fontSize: 24, fontWeight: 'bold', color: '#222', textAlign: 'center', flex: 1 },
  content: { padding: 20, paddingBottom: 40 },
  paragraph: { fontSize: 16, color: '#222', marginBottom: 14, textAlign: 'justify', lineHeight: 22 },
  bold: { fontWeight: 'bold', color: '#004d5c' },
  number: { fontWeight: 'bold', color: '#222' },
  logo: { width: 70, height: 70, alignSelf: 'center', marginTop: 24, marginBottom: 10, opacity: 0.9 },
});