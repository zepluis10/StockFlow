import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  FlatList,
  Alert,
  TextInput,
  Image,
  Keyboard,
  TouchableWithoutFeedback,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Picker } from '@react-native-picker/picker';
import Navbar from '../components/navbar';
import AddItemModal from '../components/AddItemModal';
import { Swipeable } from 'react-native-gesture-handler';
import Constants from 'expo-constants';

const { width } = Dimensions.get('window');
const API_BASE_URL = Constants.expoConfig.extra.API_URL;

export default function Inventory() {
  const [modalVisible, setModalVisible] = useState(false);
  const [items, setItems] = useState([]);
  const [searchText, setSearchText] = useState('');
  const [showSearch, setShowSearch] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [selectedCategoria, setSelectedCategoria] = useState('');
  const [precoMax, setPrecoMax] = useState('');
  const [editItem, setEditItem] = useState(null);

  const fetchItems = async () => {
    const token = await AsyncStorage.getItem('token');
    try {
      const res = await fetch(`${API_BASE_URL}/items`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (res.ok) {
        setItems(data);
      } else {
        Alert.alert('Erro', 'Não foi possível carregar os itens.');
      }
    } catch (err) {
      Alert.alert('Erro', 'Erro ao comunicar com o servidor.');
    }
  };

  useEffect(() => {
    fetchItems();
  }, []);

  const handleItemAdded = () => {
    fetchItems();
    setModalVisible(false);
  };

  const handleDeleteItem = async (itemId) => {
    const token = await AsyncStorage.getItem('token');
    try {
      const res = await fetch(`${API_BASE_URL}/items/${itemId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        fetchItems();
      } else {
        Alert.alert('Erro', 'Erro ao apagar item.');
      }
    } catch (err) {
      Alert.alert('Erro', 'Erro ao comunicar com o servidor.');
    }
  };

  const confirmDelete = (itemId) => {
    Alert.alert('Apagar Item', 'Tens a certeza que queres apagar este item?', [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Sim', onPress: () => handleDeleteItem(itemId) },
    ]);
  };

  const renderRightActions = (itemId, item) => (
    <View style={{ flexDirection: 'row', paddingRight: 8 }}>
      <TouchableOpacity
        style={[styles.editButton, { marginRight: 4 }]}
        onPress={() => {
          setEditItem(item);
          setModalVisible(true);
        }}
      >
        <Feather name="edit-2" size={24} color="#fff" />
      </TouchableOpacity>
      <TouchableOpacity style={styles.deleteButton} onPress={() => confirmDelete(itemId)}>
        <Feather name="trash-2" size={24} color="#fff" />
      </TouchableOpacity>
    </View>
  );

  const renderItem = ({ item }) => {
    const precoTotal = item.preco * item.quantidade;
    let unidadeExtra = '';
    if (item.valorUnidade && ['L', 'Kg', 'm³', 'm'].includes(item.unidade)) {
      unidadeExtra = ` (${item.valorUnidade} ${item.unidade})`;
    }
    return (
      <Swipeable renderRightActions={() => renderRightActions(item.id, item)}>
        <View style={styles.itemCard}>
          <View>
            <Text style={styles.itemNome}>
              {item.nome} <Text style={{ color: '#888' }}>#{item.codigo}</Text>
            </Text>
            <Text style={styles.itemQtd}>
              {item.quantidade}{unidadeExtra || ` ${item.unidade}`}
            </Text>
          </View>
          <Text style={styles.itemPreco}>
            {precoTotal.toLocaleString('pt-PT', { style: 'currency', currency: 'EUR' })}
          </Text>
        </View>
      </Swipeable>
    );
  };

  const categoriasUnicas = [...new Set(items.map((item) => item.categoria))];

  const filteredItems = items.filter((item) => {
    const matchNome = item.nome.toLowerCase().includes(searchText.toLowerCase());
    const matchCategoria = selectedCategoria === '' || item.categoria === selectedCategoria;
    const matchPreco = precoMax === '' || item.preco * item.quantidade <= parseFloat(precoMax);
    return matchNome && matchCategoria && matchPreco;
  });

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Inventário</Text>
        <View style={styles.icons}>
          <TouchableOpacity style={styles.iconButton} onPress={() => setShowSearch(!showSearch)}>
            <Feather name="search" size={24} color="#000" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.iconButton} onPress={() => setShowFilters(!showFilters)}>
            <Feather name="filter" size={24} color="#000" />
          </TouchableOpacity>
        </View>
      </View>

      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <View>
          {showSearch && (
            <TextInput
              placeholder="Pesquisar produto..."
              value={searchText}
              onChangeText={setSearchText}
              style={styles.input}
            />
          )}

          {showFilters && (
            <View>
              <Picker
                selectedValue={selectedCategoria}
                onValueChange={(value) => setSelectedCategoria(value)}
                style={styles.input}
              >
                <Picker.Item label="Todas as categorias" value="" />
                {categoriasUnicas.map((tipo, index) => (
                  <Picker.Item key={index} label={tipo} value={tipo} />
                ))}
              </Picker>

              <TextInput
                placeholder="Preço máximo (€)"
                value={precoMax}
                onChangeText={setPrecoMax}
                keyboardType="numeric"
                style={styles.input}
              />
            </View>
          )}
        </View>
      </TouchableWithoutFeedback>

      <View style={{ flex: 1 }}>
        {filteredItems.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Image
              source={require('../assets/caixavazia.png')}
              style={styles.image}
              resizeMode="contain"
            />
            <Text style={styles.emptyText}>Está vazio!</Text>
          </View>
        ) : (
          <FlatList
            data={filteredItems}
            keyExtractor={(item) => item.id.toString()}
            renderItem={renderItem}
            contentContainerStyle={{ paddingBottom: 120 }}
            showsVerticalScrollIndicator={true}
          />
        )}
      </View>

      <TouchableOpacity style={styles.floatingButton} onPress={() => setModalVisible(true)}>
        <Feather name="plus" size={28} color="#fff" />
      </TouchableOpacity>

      <AddItemModal
        visible={modalVisible}
        onClose={() => {
          setModalVisible(false);
          setEditItem(null);
        }}
        onItemAdded={handleItemAdded}
        onItemEdited={handleItemAdded}
        itemParaEditar={editItem}
        categoriasExistentes={categoriasUnicas}
      />

      <Navbar />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 24,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingBottom: 12,
    paddingHorizontal: 24,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#000',
  },
  icons: {
    flexDirection: 'row',
  },
  iconButton: {
    marginLeft: 20,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 16,
    marginBottom: 12,
    marginHorizontal: 24,
  },
  itemCard: {
    backgroundColor: '#f2f2f2',
    borderRadius: 10,
    padding: 16,
    marginBottom: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginHorizontal: 24,
  },
  itemNome: {
    fontSize: 14,
    color: '#555',
  },
  itemQtd: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
  },
  itemPreco: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#000',
  },
  deleteButton: {
    backgroundColor: '#d11a2a',
    justifyContent: 'center',
    alignItems: 'center',
    width: 70,
    borderRadius: 10,
    marginBottom: 12,
    marginRight: 16,
  },
  editButton: {
    backgroundColor: '#007bff',
    justifyContent: 'center',
    alignItems: 'center',
    width: 70,
    borderRadius: 10,
    marginBottom: 12,
  },
  floatingButton: {
    position: 'absolute',
    bottom: 70,
    right: 24,
    backgroundColor: '#004d5c',
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 5,
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowOffset: { width: 0, height: 3 },
    shadowRadius: 4,
    zIndex: 20,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center',
    paddingTop: 150,
  },
  image: {
    width: width * 0.4,
    height: width * 0.4,
    marginBottom: 20,
    opacity: 0.7,
  },
  emptyText: {
    fontSize: 18,
    color: '#444',
  },
});