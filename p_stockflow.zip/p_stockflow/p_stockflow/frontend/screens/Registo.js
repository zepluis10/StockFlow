import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Platform, Keyboard, KeyboardAvoidingView, TouchableWithoutFeedback, ScrollView, Alert, } from 'react-native';
import { Ionicons, MaterialIcons, Feather } from '@expo/vector-icons';
import Constants from 'expo-constants';

const API_BASE_URL = Constants.expoConfig.extra.API_URL;

export default function Registo({ navigation }) {
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [contacto, setContacto] = useState('');
  const [password, setPassword] = useState('');
  const [confirmarPassword, setConfirmarPassword] = useState('');
  const [mostrarPassword, setMostrarPassword] = useState(false);
  const [mostrarConfirmar, setMostrarConfirmar] = useState(false);
  const [codigo, setCodigo] = useState('');
  const [codigoEnviado, setCodigoEnviado] = useState(false);

  const handleSendCode = async () => {
    if (!email) {
      Alert.alert('Erro', 'Insere o email primeiro.');
      return;
    }
    try {
      const response = await fetch(`${API_BASE_URL}/auth/send-verification-code`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      const data = await response.json();
      if (response.ok) {
        setCodigoEnviado(true);
        Alert.alert('Código enviado', data.message || 'Verifica o teu email.');
      } else {
        Alert.alert('Erro', data.message || 'Não foi possível enviar o código.');
      }
    } catch (error) {
      Alert.alert('Erro', 'Erro ao enviar código.');
    }
  };

  const handleRegister = async () => {
    if (!nome || !email || !password || !confirmarPassword || !contacto) {
      Alert.alert('Erro', 'Preenche todos os campos obrigatórios.');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      Alert.alert('Erro', 'Insere um email válido.');
      return;
    }

    const telefoneRegex = /^9\d{8}$/;
    if (!telefoneRegex.test(contacto)) {
      Alert.alert('Erro', 'Insere um número de telemóvel válido (9 dígitos, começando por 9).');
      return;
    }

    if (password !== confirmarPassword) {
      Alert.alert('Erro', 'As palavras-passe não coincidem.');
      return;
    }

    try {
      const response = await fetch(`${API_BASE_URL}/auth/send-verification-code`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      const data = await response.json();
      if (response.ok) {
        navigation.navigate('RecoveryCode', {
          email,
          nome,
          password,
          contacto,
          isRegister: true,
        });
      } else {
        Alert.alert('Erro', data.message || 'Não foi possível enviar o código.');
      }
    } catch (error) {
      Alert.alert('Erro', 'Erro ao enviar código.');
    }
  };


  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 100 : 0}
    >
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <ScrollView
          contentContainerStyle={styles.scrollContainer}
          keyboardShouldPersistTaps="handled"
        >
          <Text style={styles.heading}>Vamos começar!</Text>
          <Text style={styles.subheading}>Regista-te para começares já a aproveitar!</Text>

          {/* Nome */}
          <Text style={styles.label}>Nome</Text>
          <View style={styles.inputContainer}>
            <Ionicons name="person-outline" size={20} color="#999" style={styles.icon} />
            <TextInput
              placeholder="Nome Completo"
              style={styles.input}
              value={nome}
              onChangeText={setNome}
            />
          </View>

          {/* Email */}
          <Text style={styles.label}>Email</Text>
          <View style={styles.inputContainer}>
            <MaterialIcons name="email" size={20} color="#999" style={styles.icon} />
            <TextInput
              placeholder="Email"
              style={styles.input}
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              autoCapitalize="none"
            />
          </View>

          {/* Contacto */}
          <Text style={styles.label}>Contacto</Text>
          <View style={styles.inputContainer}>
            <Feather name="phone" size={20} color="#999" style={styles.icon} />
            <TextInput
              placeholder="Nº Telemóvel"
              style={styles.input}
              value={contacto}
              onChangeText={setContacto}
              keyboardType="phone-pad"
            />
          </View>

          {/* Palavra-passe */}
          <Text style={styles.label}>Palavra-passe</Text>
          <View style={styles.inputContainer}>
            <Feather name="lock" size={20} color="#999" style={styles.icon} />
            <TextInput
              placeholder="Palavra-passe"
              style={styles.input}
              secureTextEntry={!mostrarPassword}
              value={password}
              onChangeText={setPassword}
            />
            <TouchableOpacity onPress={() => setMostrarPassword(!mostrarPassword)}>
              <Feather name={mostrarPassword ? 'eye-off' : 'eye'} size={20} color="#999" />
            </TouchableOpacity>
          </View>

          {/* Confirmar Palavra-passe */}
          <Text style={styles.label}>Confirma a Palavra-passe</Text>
          <View style={styles.inputContainer}>
            <Feather name="lock" size={20} color="#999" style={styles.icon} />
            <TextInput
              placeholder="Palavra-passe"
              style={styles.input}
              secureTextEntry={!mostrarConfirmar}
              value={confirmarPassword}
              onChangeText={setConfirmarPassword}
            />
            <TouchableOpacity onPress={() => setMostrarConfirmar(!mostrarConfirmar)}>
              <Feather name={mostrarConfirmar ? 'eye-off' : 'eye'} size={20} color="#999" />
            </TouchableOpacity>
          </View>

          <Text style={styles.helperText}>Deve ser igual à inserida anteriormente!</Text>


          <TouchableOpacity style={styles.button} onPress={handleRegister}>
            <Text style={styles.buttonText}>Confirmar Registo</Text>
          </TouchableOpacity>

          <Text style={styles.bottomText}>
            Já tens uma conta?
            <Text style={styles.loginLink} onPress={() => navigation.navigate('Login')}>
              {' '}Inicia sessão
            </Text>
          </Text>
        </ScrollView>
      </TouchableWithoutFeedback>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  scrollContainer: {
    padding: 24,
    paddingBottom: 40,
    flexGrow: 1,
    justifyContent: 'flex-start',
  },
  heading: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#004d5c',
    textAlign: 'center',
    marginBottom: 6,
  },
  subheading: {
    fontSize: 14,
    color: '#444',
    textAlign: 'center',
    marginBottom: 30,
  },
  label: {
    fontSize: 14,
    color: '#333',
    marginBottom: 6,
    marginLeft: 4,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 12,
    marginBottom: 16,
  },
  icon: {
    marginRight: 8,
  },
  input: {
    flex: 1,
    fontSize: 15,
  },
  helperText: {
    fontSize: 12,
    color: '#888',
    marginBottom: 20,
    marginLeft: 4,
  },
  button: {
    backgroundColor: '#004d5c',
    paddingVertical: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 20,
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  bottomText: {
    textAlign: 'center',
    fontSize: 15,
    color: '#444',
  },
  loginLink: {
    color: '#004d5c',
    fontWeight: 'bold',
  },
});
