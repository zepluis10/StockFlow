import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image } from 'react-native';
import { Feather } from '@expo/vector-icons';

export default function PrivacyPolicy({ navigation }) {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Feather name="arrow-left" size={28} color="#004d5c" />
        </TouchableOpacity>
        <Text style={styles.title}>Política de Privacidade</Text>
        <View style={{ width: 28 }} />
      </View>
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.paragraph}>
          <Text style={styles.number}>1. </Text>
          <Text style={styles.bold}>Introdução</Text> {"\n"}
          Esta Política de Privacidade descreve como a nossa aplicação de gestão de logística coleta, utiliza e protege as informações dos seus utilizadores. Ao utilizar a aplicação, o utilizador concorda com os termos aqui descritos.
        </Text>

        <Text style={styles.paragraph}>
          <Text style={styles.number}>2. </Text>
          <Text style={styles.bold}>Informações Coletadas</Text> {"\n"}
          A aplicação poderá coletar e armazenar as seguintes informações:
        </Text>
        <View style={styles.list}>
          <Text style={styles.listItem}>• Dados de clientes: Nome, contacto, e localização.</Text>
          <Text style={styles.listItem}>• Dados de stock: Tipo de produto, quantidade e preço.</Text>
          <Text style={styles.listItem}>• Dados de encomendas: Número de encomenda, cliente associado, data e localização.</Text>
          <Text style={styles.listItem}>• Dados de uso: Informações sobre como o utilizador interage com a aplicação.</Text>
        </View>

        <Text style={styles.paragraph}>
          <Text style={styles.number}>3. </Text>
          <Text style={styles.bold}>Uso das Informações</Text> {"\n"}
          As informações coletadas são utilizadas para:
        </Text>
        <View style={styles.list}>
          <Text style={styles.listItem}>• Gerir os clientes, stock e encomendas.</Text>
          <Text style={styles.listItem}>• Melhorar a experiência do utilizador.</Text>
          <Text style={styles.listItem}>• Garantir a segurança e integridade dos dados.</Text>
        </View>

        <Text style={styles.paragraph}>
          <Text style={styles.number}>4. </Text>
          <Text style={styles.bold}>Compartilhamento de Dados</Text> {"\n"}
          As informações dos utilizadores não serão vendidas ou compartilhadas com terceiros, exceto nos seguintes casos:
        </Text>
        <View style={styles.list}>
          <Text style={styles.listItem}>• Quando exigido por lei.</Text>
          <Text style={styles.listItem}>• Para cumprimento de obrigações legais ou regulatórias.</Text>
        </View>

        <Text style={styles.paragraph}>
          <Text style={styles.number}>5. </Text>
          <Text style={styles.bold}>Segurança dos Dados</Text> {"\n"}
          Implementamos medidas de segurança para proteger as informações contra acessos não autorizados, alterações, divulgação ou destruição indevida.
        </Text>

        <Text style={styles.paragraph}>
          <Text style={styles.number}>6. </Text>
          <Text style={styles.bold}>Direitos do Utilizador</Text> {"\n"}
          O utilizador tem o direito de:
        </Text>
        <View style={styles.list}>
          <Text style={styles.listItem}>• Acessar, corrigir ou excluir os seus dados pessoais.</Text>
          <Text style={styles.listItem}>• Solicitar informações sobre como os seus dados são tratados.</Text>
        </View>

        <Text style={styles.paragraph}>
          <Text style={styles.number}>7. </Text>
          <Text style={styles.bold}>Alterações na Política de Privacidade</Text> {"\n"}
          Esta Política de Privacidade pode ser atualizada periodicamente. Recomendamos que os utilizadores revejam regularmente eventuais alterações.
        </Text>

        <Text style={styles.paragraph}>
          <Text style={styles.number}>8. </Text>
          <Text style={styles.bold}>Contacto</Text> {"\n"}
          Para dúvidas ou solicitações relacionadas com a privacidade dos dados, entre em contacto com a nossa equipa através do suporte da aplicação.
        </Text>

        <Image
          source={require('../assets/Logo.png')}
          style={styles.logo}
          resizeMode="contain"
        />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 48,
    paddingBottom: 16,
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  title: { fontSize: 24, fontWeight: 'bold', color: '#222', textAlign: 'center', flex: 1 },
  content: { padding: 20, paddingBottom: 40 },
  paragraph: { fontSize: 16, color: '#222', marginBottom: 14, textAlign: 'justify', lineHeight: 22 },
  bold: { fontWeight: 'bold', color: '#004d5c' },
  number: { fontWeight: 'bold', color: '#222' },
  list: { marginBottom: 12, marginLeft: 10 },
  listItem: { fontSize: 16, color: '#222', marginBottom: 4, lineHeight: 22 },
  logo: { width: 70, height: 70, alignSelf: 'center', marginTop: 24, marginBottom: 10, opacity: 0.9 },
});