import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Dimensions, SafeAreaView, KeyboardAvoidingView, Platform, Alert } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Constants from 'expo-constants';

const { width, height } = Dimensions.get('window');
const API_BASE_URL = Constants.expoConfig.extra.API_URL;

export default function Login({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [mostrarPassword, setMostrarPassword] = useState(false);

  const handleLogin = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      const data = await response.json();

      if (response.ok) {
        await AsyncStorage.setItem('token', data.access_token);
        navigation.navigate('Inventory');
        Alert.alert('Sucesso', 'Login feito com sucesso!');
      } else {
        Alert.alert('Erro', data.message || 'Falha no login.');
      }
    } catch (err) {
      console.error(err);
      Alert.alert('Erro', 'Erro na comunicação com o servidor.');
    }
  };

  return (
    <SafeAreaView style={styles.safeContainer}>
      <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={styles.inner}>
          <Text style={styles.heading}>Bem-vindo de volta!</Text>
          <Text style={styles.subheading}>Inicia sessão para voltares onde paraste!</Text>

          <View style={styles.inputContainer}>
            <Feather name="mail" size={20} color="#999" style={styles.icon} />
            <TextInput
              style={styles.input}
              placeholder="Email"
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              autoCapitalize="none"
            />
          </View>

          <View style={styles.inputContainer}>
            <Feather name="lock" size={20} color="#999" style={styles.icon} />
            <TextInput
              style={styles.input}
              placeholder="Palavra-passe"
              secureTextEntry={!mostrarPassword}
              value={password}
              onChangeText={setPassword}
            />
            <TouchableOpacity onPress={() => setMostrarPassword(!mostrarPassword)}>
              <Feather name={mostrarPassword ? 'eye-off' : 'eye'} size={20} color="#999" />
            </TouchableOpacity>
          </View>

          <TouchableOpacity onPress={() => navigation.navigate('PasswordRecovery')}>
            <Text style={styles.forgotPasswordText}>Esqueceste-te da palavra-passe?</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.loginButton} onPress={handleLogin}>
            <Text style={styles.loginButtonText}>Iniciar sessão</Text>
          </TouchableOpacity>

          <Text style={styles.registerPrompt}>
            Não tens uma conta?
            <Text style={styles.registerLink} onPress={() => navigation.navigate('Registo')}>
              {' '}Registar-se
            </Text>
          </Text>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeContainer: {
    flex: 1,
    backgroundColor: '#fff',
  },
  container: {
    flex: 1,
    paddingHorizontal: '6%',
    justifyContent: 'center',
  },
  inner: {
    flex: 1,
    justifyContent: 'top',
    paddingVertical: '10%',
  },
  heading: {
    fontSize: width * 0.06,
    fontWeight: 'bold',
    color: '#004d5c',
    textAlign: 'center',
    marginBottom: 6,
  },
  subheading: {
    fontSize: width * 0.04,
    color: '#333',
    textAlign: 'center',
    marginBottom: 30,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderColor: '#ddd',
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 12,
    marginBottom: 18,
  },
  icon: {
    marginRight: 8,
  },
  input: {
    flex: 1,
    fontSize: width * 0.04,
  },
  forgotPasswordText: {
    fontSize: 13,
    color: '#444',
    textAlign: 'right',
    marginTop: -10,
    marginBottom: 20,
  },
  loginButton: {
    backgroundColor: '#004d5c',
    paddingVertical: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 20,
  },
  loginButtonText: {
    color: '#fff',
    fontSize: width * 0.045,
    fontWeight: 'bold',
  },
  registerPrompt: {
    textAlign: 'center',
    fontSize: width * 0.04,
    color: '#444',
  },
  registerLink: {
    color: '#004d5c',
    fontWeight: 'bold',
  },
});
