import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, Dimensions, ActivityIndicator, Alert, FlatList, TextInput } from 'react-native';
import { Feather } from '@expo/vector-icons';
import Navbar from '../components/navbar';
import AsyncStorage from '@react-native-async-storage/async-storage';
import AddClienteModal from '../components/AddClienteModal';
import { Swipeable } from 'react-native-gesture-handler';
import { Picker } from '@react-native-picker/picker';
import Constants from 'expo-constants';

const { width } = Dimensions.get('window');
const API_BASE_URL = Constants.expoConfig?.extra?.API_URL || 'http://localhost:3001';

export default function Clientes() {
  const [user, setUser] = useState(null);
  const [clientes, setClientes] = useState([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [searchText, setSearchText] = useState('');
  const [showSearch, setShowSearch] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [selectedLocalidade, setSelectedLocalidade] = useState('');
  const [editCliente, setEditCliente] = useState(null);

  useEffect(() => {
    const carregarPerfil = async () => {
      const token = await AsyncStorage.getItem('token');
      if (!token) {
        Alert.alert('Erro', 'Sessão expirada. Faz login novamente.');
        return;
      }
      try {
        const response = await fetch(`${API_BASE_URL}/profile`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        const data = await response.json();
        if (response.ok) {
          setUser(data.user);
        } else {
          Alert.alert('Erro', 'Token inválido ou expirado.');
        }
      } catch (error) {
        Alert.alert('Erro', 'Falha ao carregar perfil.');
      }
    };
    carregarPerfil();
  }, []);


  const fetchClientes = async () => {
    const token = await AsyncStorage.getItem('token');
    try {
      const response = await fetch(`${API_BASE_URL}/clientes`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await response.json();
      if (response.ok) {
        setClientes(data);
      } else {
        setClientes([]);
      }
    } catch (error) {
      setClientes([]);
    }
  };

  useEffect(() => {
    if (user) fetchClientes();
  }, [user]);

  const handleClienteAdded = () => {
    fetchClientes();
    setModalVisible(false);
  };

  const handleDeleteCliente = async (clienteId) => {
    const token = await AsyncStorage.getItem('token');
    try {
      const res = await fetch(`${API_BASE_URL}/clientes/${clienteId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        fetchClientes();
      } else {
        Alert.alert('Erro', 'Erro ao apagar cliente.');
      }
    } catch (err) {
      Alert.alert('Erro', 'Erro ao comunicar com o servidor.');
    }
  };

  const confirmDelete = (clienteId) => {
    Alert.alert('Apagar Cliente', 'Tens a certeza que queres apagar este cliente?', [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Sim', onPress: () => handleDeleteCliente(clienteId) },
    ]);
  };

  const renderRightActions = (clienteId, item) => (
    <View style={{ flexDirection: 'row', paddingRight: 8 }}>
      <TouchableOpacity
        style={[styles.editButton, { marginRight: 4 }]}
        onPress={() => {
          setEditCliente(item);
          setModalVisible(true);
        }}
      >
        <Feather name="edit-2" size={24} color="#fff" />
      </TouchableOpacity>
      <TouchableOpacity style={styles.deleteButton} onPress={() => confirmDelete(clienteId)}>
        <Feather name="trash-2" size={24} color="#fff" />
      </TouchableOpacity>
    </View>
  );

  const renderCliente = ({ item }) => (
    <Swipeable renderRightActions={() => renderRightActions(item.id, item)}>
      <View style={styles.clienteCard}>
        <View style={{ flex: 1 }}>
          <View style={styles.clienteHeader}>
            <Text style={styles.localidade}>{item.localidade}</Text>
            <Text style={styles.clienteEmailRight}>{item.email}</Text>
          </View>
          <View style={styles.clienteRow}>
            <Text style={styles.clienteNome}>{item.nome}</Text>
            <Text style={styles.clienteTelefone}>{item.telefone}</Text>
          </View>
        </View>
      </View>
    </Swipeable>
  );

  const localidadesUnicas = [...new Set(clientes.map((c) => c.localidade))];

  const filteredClientes = clientes.filter((cliente) => {
    const matchNome = cliente.nome.toLowerCase().includes(searchText.toLowerCase());
    const matchLocalidade = selectedLocalidade === '' || cliente.localidade === selectedLocalidade;
    return matchNome && matchLocalidade;
  });

  if (!user) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#004d5c" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Clientes</Text>
        <View style={styles.icons}>
          <TouchableOpacity style={styles.iconButton} onPress={() => setShowSearch(!showSearch)}>
            <Feather name="search" size={24} color="#000" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.iconButton} onPress={() => setShowFilters(!showFilters)}>
            <Feather name="filter" size={24} color="#000" />
          </TouchableOpacity>
        </View>
      </View>

      {/* Barra de pesquisa */}
      {showSearch && (
        <TextInput
          placeholder="Pesquisar cliente..."
          value={searchText}
          onChangeText={setSearchText}
          style={styles.input}
        />
      )}

      {/* Filtro por localidade */}
      {showFilters && (
        <View style={styles.pickerWrapper}>
          <Text style={styles.pickerLabel}>Filtrar por localidade:</Text>
          <View style={styles.pickerBox}>
            <Picker
              selectedValue={selectedLocalidade}
              onValueChange={(value) => setSelectedLocalidade(value)}
              style={styles.picker}
            >
              <Picker.Item label="Todas as localidades" value="" />
              {localidadesUnicas.map((loc, idx) => (
                <Picker.Item key={idx} label={loc} value={loc} />
              ))}
            </Picker>
          </View>
        </View>
      )}

      <View style={{ flex: 1 }}>
        {filteredClientes.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Image
              source={require('../assets/clientesvazio.png')}
              style={styles.image}
              resizeMode="contain"
            />
            <Text style={styles.emptyText}>Está vazio!</Text>
          </View>
        ) : (
          <FlatList
            data={filteredClientes}
            keyExtractor={(item) => item.id.toString()}
            renderItem={renderCliente}
            contentContainerStyle={{ paddingBottom: 120 }}
            showsVerticalScrollIndicator={true}
          />
        )}
      </View>

      <TouchableOpacity
        style={styles.floatingButton}
        onPress={() => {
          setEditCliente(null);
          setModalVisible(true);
        }}
      >
        <Feather name="plus" size={28} color="#fff" />
      </TouchableOpacity>
      <AddClienteModal
        visible={modalVisible}
        onClose={() => {
          setModalVisible(false);
          setEditCliente(null);
        }}
        onClienteAdded={handleClienteAdded}
        clienteParaEditar={editCliente}
        onClienteEditado={handleClienteAdded}
      />
      <Navbar />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 24,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingBottom: 12,
    paddingHorizontal: 24,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#000',
  },
  icons: {
    flexDirection: 'row',
  },
  iconButton: {
    marginLeft: 20,
  },
  clienteCard: {
    backgroundColor: '#f2f2f2',
    borderRadius: 10,
    paddingVertical: 10,
    paddingHorizontal: 16,
    marginBottom: 12,
    marginHorizontal: 24,
  },
  clienteHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 2,
  },
  localidade: {
    fontSize: 14,
    color: '#888',
    textAlign: 'left',
    flex: 1,
  },
  clienteEmailRight: {
    fontSize: 14,
    color: '#888',
    textAlign: 'right',
    flex: 1,
  },
  clienteRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
  },
  clienteNome: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000',
    flex: 1,
  },
  clienteTelefone: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
    textAlign: 'right',
    flex: 1,
  },
  floatingButton: {
    position: 'absolute',
    bottom: 70,
    right: 24,
    backgroundColor: '#004d5c',
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 5,
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowOffset: { width: 0, height: 3 },
    shadowRadius: 4,
    zIndex: 20,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center',
    paddingTop: 150,
  },
  image: {
    width: width * 0.4,
    height: width * 0.4,
    marginBottom: 20,
    opacity: 0.7,
  },
  emptyText: {
    fontSize: 18,
    color: '#444',
  },
  deleteButton: {
    backgroundColor: '#d11a2a',
    justifyContent: 'center',
    alignItems: 'center',
    width: 70,
    borderRadius: 10,
    marginBottom: 12,
    marginRight: 16,
  },
  editButton: {
    backgroundColor: '#007bff',
    justifyContent: 'center',
    alignItems: 'center',
    width: 70,
    borderRadius: 10,
    marginBottom: 12,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 16,
    marginBottom: 12,
    marginHorizontal: 24,
  },
  pickerWrapper: {
    marginBottom: 12,
    marginHorizontal: 24,
  },
  pickerLabel: {
    fontSize: 14,
    color: '#444',
    marginBottom: 4,
  },
  pickerBox: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    backgroundColor: '#f9f9f9',
  },
  picker: {
    width: '100%',
  },
});
