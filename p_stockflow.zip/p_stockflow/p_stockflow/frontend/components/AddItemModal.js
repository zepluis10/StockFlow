import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  Modal,
  StyleSheet,
  TouchableOpacity,
  Alert,
  TouchableWithoutFeedback,
  Keyboard,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Picker } from '@react-native-picker/picker';
import Constants from 'expo-constants';

const API_BASE_URL = Constants.expoConfig.extra.API_URL;

export default function AddItemModal({
  visible,
  onClose,
  onItemAdded,
  onItemEdited,
  itemParaEditar,
  categoriasExistentes = [],
}) {
  const [nome, setNome] = useState('');
  const [categoria, setCategoria] = useState('');
  const [preco, setPreco] = useState('');
  const [quantidade, setQuantidade] = useState('');
  const [codigo, setCodigo] = useState('');
  const [unidade, setUnidade] = useState('Unidade');
  const [valorUnidade, setValorUnidade] = useState('');

  useEffect(() => {
    if (itemParaEditar) {
      setNome(itemParaEditar.nome);
      setCategoria(itemParaEditar.categoria);
      setPreco(itemParaEditar.preco.toString());
      setQuantidade(itemParaEditar.quantidade.toString());
      setCodigo(itemParaEditar.codigo || '');
      setUnidade(itemParaEditar.unidade || 'Unidade');
      setValorUnidade(itemParaEditar.valorUnidade || '');
    } else if (!visible) {
      setNome('');
      setCategoria('');
      setPreco('');
      setQuantidade('');
      setCodigo('');
      setUnidade('Unidade');
      setValorUnidade('');
    }
  }, [visible, itemParaEditar]);

  const handleSave = async () => {
    if (!nome || !categoria || !preco || !quantidade || !codigo || !unidade) {
      Alert.alert('Erro', 'Preenche todos os campos.');
      return;
    }
    if (['L', 'Kg', 'm³', 'm'].includes(unidade) && !valorUnidade) {
      Alert.alert('Erro', 'Indica o valor da unidade.');
      return;
    }

    const token = await AsyncStorage.getItem('token');
    try {
      let response, data;
      if (itemParaEditar) {
        response = await fetch(`${API_BASE_URL}/items/${itemParaEditar.id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            nome,
            categoria,
            preco: parseFloat(preco),
            quantidade: parseInt(quantidade),
            codigo,
            unidade,
            valorUnidade: ['L', 'Kg', 'm³', 'm'].includes(unidade) ? valorUnidade : '',
          }),
        });
        data = await response.json();
        if (response.ok) {
          Alert.alert('Sucesso', 'Item atualizado com sucesso!');
          onItemEdited();
          onClose();
        } else {
          Alert.alert('Erro', data.message || 'Erro ao atualizar item.');
        }
      } else {
        response = await fetch(`${API_BASE_URL}/items`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            nome,
            categoria,
            preco: parseFloat(preco),
            quantidade: parseInt(quantidade),
            codigo,
            unidade,
            valorUnidade: ['L', 'Kg', 'm³', 'm'].includes(unidade) ? valorUnidade : '',
          }),
        });
        data = await response.json();
        if (response.ok) {
          Alert.alert('Sucesso', 'Item adicionado com sucesso!');
          onItemAdded();
          onClose();
        } else {
          Alert.alert('Erro', data.message || 'Erro ao adicionar item.');
        }
      }
    } catch (error) {
      Alert.alert('Erro', 'Erro de comunicação com o servidor.');
    }
  };

  return (
    <Modal visible={visible} animationType="slide" transparent>
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <View style={styles.overlay}>
          <View style={styles.container}>
            <Text style={styles.title}>
              {itemParaEditar ? 'Editar Item' : 'Adicionar Item'}
            </Text>
            <TextInput
              style={styles.input}
              placeholder="Nome do produto"
              value={nome}
              onChangeText={setNome}
            />
            <TextInput
              style={styles.input}
              placeholder="Categoria"
              value={categoria}
              onChangeText={setCategoria}
            />
            {categoriasExistentes.length > 0 && (
              <View style={styles.pickerWrapper}>
                <Text style={styles.pickerLabel}>Selecionar categoria existente:</Text>
                <View style={styles.pickerBox}>
                  <Picker
                    selectedValue={categoria}
                    onValueChange={(value) => setCategoria(value)}
                    style={styles.picker}
                  >
                    <Picker.Item label="Nova Categoria..." value="" />
                    {categoriasExistentes.map((cat, index) => (
                      <Picker.Item key={index} label={cat} value={cat} />
                    ))}
                  </Picker>
                </View>
              </View>
            )}
            <TextInput
              style={styles.input}
              placeholder="Preço por un/L/Kg/m/m³"
              keyboardType="decimal-pad"
              value={preco}
              onChangeText={setPreco}
            />
            <TextInput
              style={styles.input}
              placeholder="Quantidade"
              keyboardType="number-pad"
              value={quantidade}
              onChangeText={setQuantidade}
            />

            <View style={styles.unidadeRow}>
              <TouchableOpacity
                style={[
                  styles.unidadeBtn,
                  unidade === 'Un' ? styles.unidadeBtnSelected : null,
                ]}
                onPress={() => setUnidade('Un')}
              >
                <Text style={[
                  styles.unidadeBtnText,
                  unidade === 'Un' ? styles.unidadeBtnTextSelected : null,
                ]}>Un</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[
                  styles.unidadeBtn,
                  unidade === 'L' ? styles.unidadeBtnSelected : null,
                ]}
                onPress={() => setUnidade('L')}
              >
                <Text style={[
                  styles.unidadeBtnText,
                  unidade === 'L' ? styles.unidadeBtnTextSelected : null,
                ]}>L</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[
                  styles.unidadeBtn,
                  unidade === 'Kg' ? styles.unidadeBtnSelected : null,
                ]}
                onPress={() => setUnidade('Kg')}
              >
                <Text style={[
                  styles.unidadeBtnText,
                  unidade === 'Kg' ? styles.unidadeBtnTextSelected : null,
                ]}>Kg</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[
                  styles.unidadeBtn,
                  unidade === 'm³' ? styles.unidadeBtnSelected : null,
                ]}
                onPress={() => setUnidade('m³')}
              >
                <Text style={[
                  styles.unidadeBtnText,
                  unidade === 'm³' ? styles.unidadeBtnTextSelected : null,
                ]}>m³</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[
                  styles.unidadeBtn,
                  unidade === 'm' ? styles.unidadeBtnSelected : null,
                ]}
                onPress={() => setUnidade('m')}
              >
                <Text style={[
                  styles.unidadeBtnText,
                  unidade === 'm' ? styles.unidadeBtnTextSelected : null,
                ]}>m</Text>
              </TouchableOpacity>
              {/* Caixa de texto só se unidade for L, Kg, m³ ou m */}
              {['L', 'Kg', 'm³', 'm'].includes(unidade) && (
                <TextInput
                  style={[styles.input, { width: 60, marginBottom: 0, marginLeft: 8 }]}
                  placeholder="Valor"
                  keyboardType="numeric"
                  value={valorUnidade}
                  onChangeText={setValorUnidade}
                />
              )}
            </View>

            <TextInput
              style={styles.input}
              placeholder="Código do Produto (#)"
              value={codigo}
              onChangeText={setCodigo}
              keyboardType="number-pad"
            />

            <View style={styles.buttons}>
              <TouchableOpacity style={styles.cancelBtn} onPress={onClose}>
                <Text style={styles.btnText}>Cancelar</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.addBtn} onPress={handleSave}>
                <Text style={styles.btnText}>{itemParaEditar ? 'Salvar' : 'Adicionar'}</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </TouchableWithoutFeedback>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  container: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    width: '90%',
    maxWidth: 320,
    elevation: 6,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 12,
    color: '#004d5c',
    textAlign: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    padding: 8,
    marginBottom: 10,
    fontSize: 15,
  },
  unidadeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
    gap: 4,
  },
  unidadeBtn: {
    backgroundColor: '#eee',
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 6,
    marginLeft: 4,
    borderWidth: 1,
    borderColor: '#ccc',
  },
  unidadeBtnSelected: {
    backgroundColor: '#004d5c',
    borderColor: '#004d5c',
  },
  unidadeBtnText: {
    color: '#004d5c',
    fontWeight: 'bold',
  },
  unidadeBtnTextSelected: {
    color: '#fff',
  },
  buttons: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 10,
  },
  cancelBtn: {
    backgroundColor: '#888',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 6,
  },
  addBtn: {
    backgroundColor: '#004d5c',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 6,
  },
  btnText: {
    color: '#fff',
    fontWeight: 'bold',
  },
});

