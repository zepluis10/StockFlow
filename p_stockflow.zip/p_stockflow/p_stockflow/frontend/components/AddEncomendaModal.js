import React, { useState, useEffect } from 'react';
import { View, Text, Modal, StyleSheet, TouchableOpacity, Alert, TouchableWithoutFeedback, Keyboard } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { TextInput } from 'react-native';
import Constants from 'expo-constants';

const API_BASE_URL = Constants.expoConfig.extra.API_URL;

export default function AddEncomendaModal({
  visible,
  onClose,
  clientes,
  items,
  onEncomendaAdded,
  encomendaParaEditar,
}) {
  const [clienteId, setClienteId] = useState('');
  const [itemId, setItemId] = useState('');
  const [quantidade, setQuantidade] = useState('');

  useEffect(() => {
    if (encomendaParaEditar) {
      setClienteId(encomendaParaEditar.cliente.id.toString());
      setItemId(encomendaParaEditar.item.id.toString());
      setQuantidade(encomendaParaEditar.quantidade.toString());
    } else if (!visible) {
      setClienteId('');
      setItemId('');
      setQuantidade('');
    }
  }, [visible, encomendaParaEditar]);

  const handleSave = async () => {
    if (!clienteId || !itemId || !quantidade) {
      Alert.alert('Erro', 'Preenche todos os campos.');
      return;
    }
    const token = await AsyncStorage.getItem('token');
    try {
      let response, data;
      if (encomendaParaEditar) {
        response = await fetch(`${API_BASE_URL}/encomendas/${encomendaParaEditar.id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            clienteId: Number(clienteId),
            itemId: Number(itemId),
            quantidade: Number(quantidade),
          }),
        });
        data = await response.json();
        if (response.ok) {
          Alert.alert('Sucesso', 'Encomenda atualizada com sucesso!');
          onEncomendaAdded();
          onClose();
        } else {
          Alert.alert('Erro', data.message || 'Erro ao atualizar encomenda.');
        }
      } else {
        response = await fetch(`${API_BASE_URL}/encomendas`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            clienteId: Number(clienteId),
            itemId: Number(itemId),
            quantidade: Number(quantidade),
          }),
        });
        data = await response.json();
        if (response.ok) {
          Alert.alert('Sucesso', 'Encomenda adicionada!');
          onEncomendaAdded();
          onClose();
        } else {
          Alert.alert('Erro', data.message || 'Erro ao adicionar encomenda.');
        }
      }
    } catch (error) {
      Alert.alert('Erro', 'Erro de comunicação com o servidor.');
    }
  };

  return (
    <Modal visible={visible} animationType="slide" transparent>
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <View style={styles.overlay}>
          <View style={styles.container}>
            <Text style={styles.title}>
              {encomendaParaEditar ? 'Editar Encomenda' : 'Adicionar Encomenda'}
            </Text>
            <Text style={styles.label}>Cliente:</Text>
            <Picker selectedValue={clienteId} onValueChange={setClienteId} style={styles.input}>
              <Picker.Item label="Selecione o cliente" value="" />
              {clientes.map((c) => (
                <Picker.Item key={c.id} label={c.nome} value={c.id.toString()} />
              ))}
            </Picker>
            <Text style={styles.label}>Produto:</Text>
            <Picker
              selectedValue={itemId}
              onValueChange={(value) => setItemId(value)}
              style={styles.input}
            >
              <Picker.Item label="Selecione o produto" value="" />
              {items.map((item) => {
                let unidadeExtra = '';
                if (item.valorUnidade && ['L', 'Kg', 'm³', 'm'].includes(item.unidade)) {
                  unidadeExtra = ` (${item.valorUnidade} ${item.unidade})`;
                }
                return (
                  <Picker.Item
                    key={item.id}
                    label={`${item.nome}${unidadeExtra}`}
                    value={item.id.toString()}
                  />
                );
              })}
            </Picker>
            <Text style={styles.label}>Quantidade:</Text>
            <View style={styles.inputBox}>
              <TextInput
                style={styles.textInput}
                placeholder="Quantidade"
                keyboardType="number-pad"
                value={quantidade}
                onChangeText={setQuantidade}
              />
            </View>
            <View style={styles.buttons}>
              <TouchableOpacity style={styles.cancelBtn} onPress={onClose}>
                <Text style={styles.btnText}>Cancelar</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.addBtn} onPress={handleSave}>
                <Text style={styles.btnText}>
                  {encomendaParaEditar ? 'Salvar' : 'Adicionar'}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </TouchableWithoutFeedback>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { 
     flex: 1,
     justifyContent: 'center', 
     alignItems: 'center', 
     backgroundColor: 'rgba(0,0,0,0.5)' 
    },

   container: {
     backgroundColor: '#fff', 
     borderRadius: 12, 
     padding: 24, 
     width: '90%', 
     maxWidth: 400, 
     elevation: 6
   },
   
  title: {
     fontSize: 20, 
     fontWeight: 'bold', 
     marginBottom: 16, 
     color: '#004d5c', 
     textAlign: 'center' 
    
    },
  label: { 
    fontSize: 16, 
    marginTop: 8, 
    marginBottom: 2 
  },
  
  input: { 
    borderWidth: 1, 
    borderColor: '#ccc', 
    borderRadius: 8, 
    marginBottom: 12 
  },
  inputBox: { 
    borderWidth: 1, 
    borderColor: '#ccc', 
    borderRadius: 8, 
    marginBottom: 12 
  },
  textInput: { 
    padding: 10, 
    fontSize: 16 
  },
  buttons: { 
    flexDirection: 'row', 
    justifyContent: 'flex-end', 
    gap: 10 
  },
  cancelBtn: { 
    backgroundColor: '#888', 
    paddingVertical: 10, 
    paddingHorizontal: 20, 
    borderRadius: 6 
  },
  addBtn: { 
    backgroundColor: '#004d5c', 
    paddingVertical: 10, 
    paddingHorizontal: 20, 
    borderRadius: 6 
  },
  btnText: { color: '#fff', 
    fontWeight: 'bold' 
  },
  
});