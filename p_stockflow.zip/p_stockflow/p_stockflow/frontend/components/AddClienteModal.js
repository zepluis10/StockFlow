import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  Modal,
  StyleSheet,
  TouchableOpacity,
  Alert,
  TouchableWithoutFeedback,
  Keyboard,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Constants from 'expo-constants';

const API_BASE_URL = Constants.expoConfig?.extra?.API_URL || 'http://localhost:3001';

export default function AddClienteModal({
  visible,
  onClose,
  onClienteAdded,
  clienteParaEditar,
  onClienteEditado,
}) {
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [telefone, setTelefone] = useState('');
  const [localidade, setLocalidade] = useState('');

  useEffect(() => {
    if (clienteParaEditar) {
      setNome(clienteParaEditar.nome);
      setEmail(clienteParaEditar.email);
      setTelefone(clienteParaEditar.telefone);
      setLocalidade(clienteParaEditar.localidade);
    } else if (!visible) {
      setNome('');
      setEmail('');
      setTelefone('');
      setLocalidade('');
    }
  }, [visible, clienteParaEditar]);

  const validateEmail = (email) => {
    return /^[a-zA-Z0-9._%+-]+@gmail\.com$/.test(email);
  };

  const validateTelefone = (telefone) => {
    return /^[0-9]{9}$/.test(telefone);
  };

  const handleSave = async () => {
    if (!nome || !email || !telefone || !localidade) {
      Alert.alert('Erro', 'Preenche todos os campos.');
      return;
    }
    if (!validateEmail(email)) {
      Alert.alert('Erro', 'Email Inválido. ');
      return;
    }
    if (!validateTelefone(telefone)) {
      Alert.alert('Erro', 'Número de telefone inválido.');
      return;
    }

    const token = await AsyncStorage.getItem('token');
    try {
      let response, data;
      if (clienteParaEditar) {
        response = await fetch(`${API_BASE_URL}/clientes/${clienteParaEditar.id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ nome, email, telefone, localidade }),
        });
        data = await response.json();
        if (response.ok) {
          Alert.alert('Sucesso', 'Cliente atualizado com sucesso!');
          onClienteEditado();
          onClose();
        } else {
          Alert.alert('Erro', data.message || 'Erro ao atualizar cliente.');
        }
      } else {
        response = await fetch(`${API_BASE_URL}/clientes`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ nome, email, telefone, localidade }),
        });
        data = await response.json();
        if (response.ok) {
          Alert.alert('Sucesso', 'Cliente adicionado com sucesso!');
          onClienteAdded();
          onClose();
        } else {
          Alert.alert('Erro', data.message || 'Erro ao adicionar cliente.');
        }
      }
    } catch (error) {
      Alert.alert('Erro', 'Erro de comunicação com o servidor.');
    }
  };

  return (
    <Modal visible={visible} animationType="slide" transparent>
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <View style={styles.overlay}>
          <View style={styles.container}>
            <Text style={styles.title}>
              {clienteParaEditar ? 'Editar Cliente' : 'Adicionar Cliente'}
            </Text>

            <TextInput
              style={styles.input}
              placeholder="Nome"
              value={nome}
              onChangeText={setNome}
            />

            <TextInput
              style={styles.input}
              placeholder="Email"
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
            />

            <TextInput
              style={styles.input}
              placeholder="Telefone"
              value={telefone}
              onChangeText={setTelefone}
              keyboardType="phone-pad"
            />

            <TextInput
              style={styles.input}
              placeholder="Localidade"
              value={localidade}
              onChangeText={setLocalidade}
            />

            <View style={styles.buttons}>
              <TouchableOpacity style={styles.cancelBtn} onPress={onClose}>
                <Text style={styles.btnText}>Cancelar</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.addBtn} onPress={handleSave}>
                <Text style={styles.btnText}>
                  {clienteParaEditar ? 'Salvar' : 'Adicionar'}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </TouchableWithoutFeedback>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  container: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 24,
    width: '90%',
    maxWidth: 400,
    elevation: 6,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 16,
    color: '#004d5c',
    textAlign: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    padding: 10,
    marginBottom: 12,
    fontSize: 16,
  },
  buttons: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 10,
  },
  cancelBtn: {
    backgroundColor: '#888',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 6,
  },
  addBtn: {
    backgroundColor: '#004d5c',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 6,
  },
  btnText: {
    color: '#fff',
    fontWeight: 'bold',
  },
});

