
import React from 'react';
import { View, TouchableOpacity, StyleSheet, Dimensions } from 'react-native';
import { Feather, Ionicons } from '@expo/vector-icons';
import { useNavigation, useRoute } from '@react-navigation/native';

const { width } = Dimensions.get('window');

export default function Navbar() {
  const navigation = useNavigation();
  const route = useRoute();

  const currentRoute = route.name;

  return (
    <View style={styles.navbar}>
      <TouchableOpacity
        style={styles.navItem}
        onPress={() => navigation.navigate('Sumario')}
      >
        <Feather
          name="home"
          size={24}
          color={currentRoute === 'Sumario' ? '#004d5c' : '#4444'}
        />
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.navItem}
        onPress={() => navigation.navigate('Inventory')}
      >
        <Feather
          name="box"
          size={24}
          color={currentRoute === 'Inventory' ? '#004d5c' : '#4444'}
        />
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.navItem}
        onPress={() => navigation.navigate('Encomendas')}
      >
        <Ionicons
          name="cart-outline"
          size={24}
          color={currentRoute === 'Encomendas' ? '#004d5c' : '#4444'}
        />
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.navItem}
        onPress={() => navigation.navigate('Clientes')}
      >
        <Feather
          name="users"
          size={24}
          color={currentRoute === 'Clientes' ? '#004d5c' : '#4444'}
        />
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.navItem}
        onPress={() => navigation.navigate('Definicoes')}
      >
        <Feather
          name="settings"
          size={24}
          color={currentRoute === 'Definicoes' ? '#004d5c' : '#4444'}
        />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  navbar: {
    position: 'absolute',
    bottom: 0,
    width: width,
    height: 60,
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#ccc',
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    paddingHorizontal: 10,
    zIndex: 1000,
  },
  navItem: {
    flex: 1,
    alignItems: 'center',
  },
});
