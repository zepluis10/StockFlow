import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { GestureHandlerRootView } from 'react-native-gesture-handler';

import WelcomeScreen from './screens/WelcomeScreen';
import Registo from './screens/Registo';
import Login from './screens/login';
import PasswordRecovery from './screens/password';
import Sumario from './screens/Sumario';
import RecoveryCodeScreen from './screens/RecoveryCodeScreen';
import NovaPasswordScreen from './screens/NovaPasswordScreen';
import Inventory from './screens/Inventory';
import Navbar from './components/navbar';
import Encomendas from './screens/Encomendas';
import Clientes from './screens/Clientes';
import Definicoes from './screens/Definicoes';
import EditProfileScreen from './screens/EditProfile';
import AboutUs from './screens/AboutUs';
import PrivacyPolicy from './screens/PrivacyPolicy';
import Terms from './screens/Terms';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <NavigationContainer>
        <Stack.Navigator
          initialRouteName="WelcomeScreen"
          screenOptions={{
            animation: 'none',
          }}
        >

          <Stack.Screen
            name="WelcomeScreen"
            component={WelcomeScreen}
            options={{
              headerShown: false,
              title: '',
            }}
          />

          <Stack.Screen
            name="Registo"
            component={Registo}
            options={{
              headerBackVisible: false,
              headerTitle: 'Registo',
              headerShadowVisible: false,
              gestureEnabled: false,
            }}
          />

          <Stack.Screen
            name="Login"
            component={Login}
            options={{
              headerBackVisible: false,
              headerTitle: 'Iniciar Sessão',
              headerShadowVisible: false,
              gestureEnabled: false,
            }}
          />

          <Stack.Screen
            name="PasswordRecovery"
            component={PasswordRecovery}
            options={{
              headerBackVisible: false,
              headerTitle: 'Recuperar Palavra-passe',
              headerShadowVisible: false,
              gestureEnabled: false,
            }}
          />

          <Stack.Screen
            name="RecoveryCode"
            component={RecoveryCodeScreen}
            options={({ navigation }) => ({
              title: 'Código de Recuperação',
              headerLeft: () => (
                <TouchableOpacity
                  onPress={() => navigation.goBack()}
                  style={{ paddingHorizontal: 12 }}
                >
                  <Ionicons name="arrow-back" size={24} color="#004d5c" />
                </TouchableOpacity>
              ),
            })}
          />

          <Stack.Screen
            name="NovaPassword"
            component={NovaPasswordScreen}
            options={({ navigation }) => ({
              title: 'Alterar Palavra-passe',
              headerLeft: () => (
                <TouchableOpacity
                  onPress={() => navigation.goBack()}
                  style={{ paddingHorizontal: 12 }}
                >
                  <Ionicons name="arrow-back" size={24} color="#004d5c" />
                </TouchableOpacity>
              ),
            })}
          />

          <Stack.Screen
            name="Sumario"
            component={Sumario}
            options={{
              headerBackVisible: false,
              headerTitle: 'StockFlow',
              headerShadowVisible: false,
              gestureEnabled: false,
            }}
          />

          <Stack.Screen
            name="Inventory"
            component={Inventory}
            options={{
              headerBackVisible: false,
              headerTitle: 'StockFlow',
              headerShadowVisible: false,
              gestureEnabled: false,
            }}
          />
          <Stack.Screen
            name="Encomendas"
            component={Encomendas}
            options={{
              headerBackVisible: false,
              headerTitle: 'StockFlow',
              headerShadowVisible: false,
              gestureEnabled: false,
            }}
          />

          <Stack.Screen
            name="Clientes"
            component={Clientes}
            options={{
              headerBackVisible: false,
              headerTitle: 'StockFlow',
              headerShadowVisible: false,
              gestureEnabled: false,
            }}
          />

          <Stack.Screen
            name="Definicoes"
            component={Definicoes}
            options={{
              headerBackVisible: false,
              headerTitle: 'StockFlow',
              headerShadowVisible: false,
              gestureEnabled: false,
            }}
          />

          <Stack.Screen
            name="EditProfile"
            component={EditProfileScreen}
            options={({ navigation }) => ({
              title: 'Editar Perfil',
              headerLeft: () => (
                <TouchableOpacity
                  onPress={() => navigation.goBack()}
                  style={{ paddingHorizontal: 12 }}
                >
                  <Ionicons name="arrow-back" size={24} color="#004d5c" />
                </TouchableOpacity>
              ),
            })}
          />

          <Stack.Screen
            name="AboutUs"
            component={AboutUs}
            options={{
              headerShown: false,
            }}
          />

          <Stack.Screen
            name="PrivacyPolicy"
            component={PrivacyPolicy}
            options={{
              headerShown: false,
            }}
          />

          <Stack.Screen
            name="Terms"
            component={Terms}
            options={{
              headerShown: false,
            }}
          />

        </Stack.Navigator>
      </NavigationContainer>
    </GestureHandlerRootView>
  );
}
