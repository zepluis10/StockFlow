import { Controller, Post, Body, UseGuards, Request, Get, Put, Delete, Param, NotFoundException } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { EncomendaService } from './encomenda.service';
import { CreateEncomendaDto } from './dto/create-encomenda.dto';

@Controller('encomendas')
@UseGuards(AuthGuard('jwt'))
export class EncomendaController {
  constructor(private readonly encomendaService: EncomendaService) { }

  @Post()
  addEncomenda(@Body() dto: CreateEncomendaDto, @Request() req) {
    return this.encomendaService.addEncomenda(dto, req.user);
  }

  @Get()
  getUserEncomendas(@Request() req) {
    return this.encomendaService.getEncomendasForUser(req.user.userId);
  }

  @Put(':id')
  async updateEncomenda(@Param('id') id: number, @Body() dto: CreateEncomendaDto, @Request() req) {
    return this.encomendaService.updateEncomenda(id, dto, req.user.userId);
  }

  @Delete(':id')
  async deleteEncomenda(@Param('id') id: number, @Request() req) {
    const deleted = await this.encomendaService.deleteEncomenda(id, req.user.userId);
    if (!deleted) {
      throw new NotFoundException('Encomenda não encontrada ou não pertence a este utilizador.');
    }
    return { message: 'Encomenda apagada com sucesso.' };
  }
}