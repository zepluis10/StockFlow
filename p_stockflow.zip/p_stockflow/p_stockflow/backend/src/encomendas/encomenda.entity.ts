import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn } from 'typeorm';
import { Cliente } from '../clientes/cliente.entity';
import { Item } from '../items/item.entity';
import { User } from '../auth/user.entity';

@Entity('encomendas')
export class Encomenda {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => Cliente, { onDelete: 'CASCADE' })
  @JoinColumn()
  cliente: Cliente;

  @ManyToOne(() => Item, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn()
  item: Item | null;

  @Column()
  quantidade: number;

  @Column()
  itemNome: string;

  @Column('decimal', { precision: 10, scale: 2 })
  itemPreco: number;

  @ManyToOne(() => User)
  @JoinColumn()
  user: User;
}