export class CreateEncomendaDto {
  clienteId: number;
  itemId: number;
  quantidade: number;
}