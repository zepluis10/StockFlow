import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Encomenda } from './encomenda.entity';
import { CreateEncomendaDto } from './dto/create-encomenda.dto';
import { Cliente } from '../clientes/cliente.entity';
import { Item } from '../items/item.entity';

@Injectable()
export class EncomendaService {
  constructor(
    @InjectRepository(Encomenda)
    private readonly encomendaRepo: Repository<Encomenda>,
    @InjectRepository(Cliente)
    private readonly clienteRepo: Repository<Cliente>,
    @InjectRepository(Item)
    private readonly itemRepo: Repository<Item>,
  ) { }

  async addEncomenda(dto: CreateEncomendaDto, user: any) {
    const cliente = await this.clienteRepo.findOne({ where: { id: dto.clienteId, user: { id: user.userId } } });
    const item = await this.itemRepo.findOne({ where: { id: dto.itemId, user: { id: user.userId } } });
    if (!cliente || !item) throw new Error('Cliente ou Item inválido');
    if (item.quantidade < dto.quantidade) throw new Error('Quantidade insuficiente em stock');

    item.quantidade -= dto.quantidade;
    await this.itemRepo.save(item);

    const encomenda = this.encomendaRepo.create({
      cliente,
      item,
      quantidade: dto.quantidade,
      itemNome: item.nome,
      itemPreco: item.preco,
      user: { id: user.userId },
    });
    return this.encomendaRepo.save(encomenda);
  }

  async getEncomendasForUser(userId: number) {
    return this.encomendaRepo.find({
      where: { user: { id: userId } },
      relations: ['cliente', 'item'],
      order: { id: 'DESC' },
    });
  }

  async updateEncomenda(id: number, dto: CreateEncomendaDto, userId: number) {
    const encomenda = await this.encomendaRepo.findOne({
      where: { id, user: { id: userId } },
      relations: ['item', 'cliente'],
    });
    if (!encomenda) throw new Error('Encomenda não encontrada ou não pertence a este utilizador.');

    const cliente = await this.clienteRepo.findOne({ where: { id: dto.clienteId, user: { id: userId } } });
    const item = await this.itemRepo.findOne({ where: { id: dto.itemId, user: { id: userId } } });
    if (!cliente || !item) throw new Error('Cliente ou Item inválido');

    const quantidadeAnterior = encomenda.quantidade;
    const novaQuantidade = dto.quantidade;
    const diferencaQuantidade = novaQuantidade - quantidadeAnterior;

    if (diferencaQuantidade > 0 && item.quantidade < diferencaQuantidade) {
      throw new Error('Quantidade insuficiente em stock para esta alteração');
    }

    item.quantidade -= diferencaQuantidade;
    await this.itemRepo.save(item);

    encomenda.cliente = cliente;
    encomenda.item = item;
    encomenda.quantidade = dto.quantidade;
    encomenda.itemNome = item.nome;
    encomenda.itemPreco = item.preco;

    return this.encomendaRepo.save(encomenda);
  }

  async deleteEncomenda(id: number, userId: number): Promise<boolean> {
    const encomenda = await this.encomendaRepo.findOne({
      where: { id, user: { id: userId } },
      relations: ['item'],
    });
    if (!encomenda) return false;

    if (encomenda.item) {
      encomenda.item.quantidade += encomenda.quantidade;
      await this.itemRepo.save(encomenda.item);
    }

    await this.encomendaRepo.remove(encomenda);
    return true;
  }
}