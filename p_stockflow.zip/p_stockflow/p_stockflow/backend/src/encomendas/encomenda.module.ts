import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Encomenda } from './encomenda.entity';
import { EncomendaService } from './encomenda.service';
import { EncomendaController } from './encomenda.controller';
import { Cliente } from '../clientes/cliente.entity';
import { Item } from '../items/item.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Encomenda, Cliente, Item])],
  providers: [EncomendaService],
  controllers: [EncomendaController],
})
export class EncomendaModule { }