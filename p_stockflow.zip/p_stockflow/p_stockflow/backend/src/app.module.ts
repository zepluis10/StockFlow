import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthModule } from './auth/auth.module';
import { ProfileModule } from './profile/profile.module';
import { ItemModule } from './items/item.module';
import { User } from './auth/user.entity';
import { Item } from './items/item.entity';
import { Cliente } from './clientes/cliente.entity';
import { ClienteModule } from './clientes/cliente.module';
import { EncomendaModule } from './encomendas/encomenda.module';
import { Encomenda } from './encomendas/encomenda.entity';
import { ConfigModule } from '@nestjs/config';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    TypeOrmModule.forRoot({
      type: 'mysql',
      host: process.env.DB_HOST,
      port: parseInt(process.env.DB_PORT || '3306', 10),
      username: process.env.DB_USER,
      password: process.env.DB_PASS,
      database: process.env.DB_NAME,
      autoLoadEntities: true,
      synchronize: true,
      entities: [User, Item, Cliente, Encomenda],
    }),
    AuthModule,
    ProfileModule,
    ItemModule,
    ClienteModule,
    EncomendaModule,
  ],
})
export class AppModule { }
