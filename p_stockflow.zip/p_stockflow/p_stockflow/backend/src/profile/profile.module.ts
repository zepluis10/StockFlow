import { Module } from '@nestjs/common';
import { ProfileController } from './profile.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from '../auth/user.entity';
import { MulterModule } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import * as path from 'path';
import * as fs from 'fs';

@Module({
  imports: [
    TypeOrmModule.forFeature([User]),
    MulterModule.register({
      storage: diskStorage({
        destination: (req, file, cb) => {
          console.log('=== MULTER DESTINATION ===');
          const uploadPath = './uploads/avatars';
          if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
            console.log('Created directory:', uploadPath);
          }
          console.log('Using destination:', uploadPath);
          cb(null, uploadPath);
        },
        filename: (req, file, cb) => {
          console.log('=== MULTER FILENAME ===');
          console.log('Original filename:', file.originalname);
          const ext = path.extname(file.originalname);
          const filename = `${Date.now()}-${Math.round(Math.random() * 1e9)}${ext}`;
          console.log('Generated filename:', filename);
          cb(null, filename);
        },
      }),
      fileFilter: (req, file, cb) => {
        console.log('=== MULTER FILE FILTER ===');
        console.log('File mimetype:', file.mimetype);
        if (!file.mimetype.startsWith('image/')) {
          console.log('File rejected: not an image');
          return cb(new Error('Apenas imagens são permitidas!'), false);
        }
        console.log('File accepted');
        cb(null, true);
      },
      limits: { fileSize: 2 * 1024 * 1024 }, 
    }),
  ],
  controllers: [ProfileController],
})
export class ProfileModule {}
