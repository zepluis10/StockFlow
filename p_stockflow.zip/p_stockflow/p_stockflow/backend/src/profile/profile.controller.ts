import { Controller, Get, Put, Body, UseGuards, Request, Post, UploadedFile, UseInterceptors, BadRequestException, Delete } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from '../auth/user.entity';
import { FileInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import * as path from 'path';
import * as fs from 'fs';
import * as bcrypt from 'bcrypt';

@Controller('profile')
export class ProfileController {
  constructor(
    @InjectRepository(User)
    private readonly userRepo: Repository<User>,
  ) { }

  @UseGuards(AuthGuard('jwt'))
  @Get()
  async getProfile(@Request() req) {
    const user = await this.userRepo.findOne({ where: { id: req.user.userId } });
    if (!user) {
      return { message: 'Utilizador não encontrado.' };
    }
    const { password, ...userData } = user;
    return {
      message: 'Perfil carregado com sucesso',
      user: userData,
    };
  }

  @UseGuards(AuthGuard('jwt'))
  @Put()
  async updateProfile(@Request() req, @Body() body: { nome: string, email: string, contacto: string, avatarUrl?: string }) {
    const user = await this.userRepo.findOne({ where: { id: req.user.userId } });
    if (!user) {
      return { message: 'Utilizador não encontrado.' };
    }
    user.nome = body.nome;
    user.email = body.email;
    user.contacto = body.contacto;
    if (body.avatarUrl !== undefined) user.avatarUrl = body.avatarUrl;
    await this.userRepo.save(user);
    return { message: 'Perfil atualizado com sucesso.' };
  }

  @UseGuards(AuthGuard('jwt'))
  @Post('avatar')
  @UseInterceptors(FileInterceptor('avatar'))
  async uploadAvatar(@Request() req, @UploadedFile() file: Express.Multer.File) {
    try {
      if (!file) {
        throw new BadRequestException('Nenhum ficheiro enviado.');
      }
      const user = await this.userRepo.findOne({ where: { id: req.user.userId } });
      if (!user) {
        throw new BadRequestException('Utilizador não encontrado.');
      }
      const appUrl = process.env.APP_URL || 'http://localhost:3001';
      user.avatarUrl = `${appUrl}/uploads/avatars/${file.filename}`;
      await this.userRepo.save(user);
      return {
        message: 'Avatar carregado com sucesso',
        avatarUrl: user.avatarUrl,
      };
    } catch (error) {
      throw new BadRequestException(error.message || 'Falha ao fazer upload do avatar');
    }
  }

  @UseGuards(AuthGuard('jwt'))
  @Delete()
  async deleteAccount(@Request() req) {
    const user = await this.userRepo.findOne({ where: { id: req.user.userId } });
    if (!user) {
      throw new BadRequestException('Utilizador não encontrado.');
    }
    const entityManager = this.userRepo.manager;
    await entityManager.query('DELETE FROM encomendas WHERE userId = ?', [user.id]);
    await entityManager.query('DELETE FROM items WHERE userId = ?', [user.id]);
    await entityManager.query('DELETE FROM clientes WHERE userId = ?', [user.id]);
    const result = await this.userRepo.delete(user.id);
    if (result.affected === 0) {
      throw new BadRequestException('Falha ao apagar o utilizador.');
    }
    return { message: 'Conta e todos os dados associados eliminados com sucesso.' };
  }

  @UseGuards(AuthGuard('jwt'))
  @Put('password')
  async changePassword(@Request() req, @Body() body: { password: string }) {
    const user = await this.userRepo.findOne({ where: { id: req.user.userId } });
    if (!user) {
      throw new BadRequestException('Utilizador não encontrado.');
    }
    user.password = await bcrypt.hash(body.password, 10);
    await this.userRepo.save(user);
    return { message: 'Palavra-passe alterada com sucesso.' };
  }
}
