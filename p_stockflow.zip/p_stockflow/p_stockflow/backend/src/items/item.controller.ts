import {
  Controller,
  Post,
  Body,
  UseGuards,
  Request,
  Get,
  Delete,
  Param,
  NotFoundException,
  Put,
} from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { ItemService } from './item.service';
import { CreateItemDto } from './dto/create-item.dto';

@Controller('items')
@UseGuards(AuthGuard('jwt'))
export class ItemController {
  constructor(private readonly itemService: ItemService) { }

  @Post()
  addItem(@Body() dto: CreateItemDto, @Request() req) {
    return this.itemService.addItem(dto, req.user);
  }

  @Get()
  getUserItems(@Request() req) {
    return this.itemService.getItemsForUser(req.user.userId);
  }

  @Delete(':id')
  async deleteItem(@Param('id') id: number, @Request() req) {
    const deleted = await this.itemService.deleteItem(id, req.user.userId);
    if (!deleted) {
      throw new NotFoundException('Item não encontrado ou não pertence a este utilizador.');
    }
    return { message: 'Item apagado com sucesso.' };
  }

  @Put(':id')
  async updateItem(@Param('id') id: number, @Body() dto: CreateItemDto, @Request() req) {
    return this.itemService.updateItem(id, dto, req.user.userId);
  }
}
