export class CreateItemDto {
  nome: string;
  categoria: string;
  preco: number;
  quantidade: number;
  codigo: string;
  unidade: string;
  valorUnidade?: string;
}
