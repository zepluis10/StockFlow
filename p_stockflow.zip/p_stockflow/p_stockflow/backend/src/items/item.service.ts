import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Item } from './item.entity';
import { CreateItemDto } from './dto/create-item.dto';
import { User } from '../auth/user.entity';

@Injectable()
export class ItemService {
  constructor(
    @InjectRepository(Item)
    private readonly itemRepo: Repository<Item>,
  ) { }

  async addItem(dto: CreateItemDto, user: any) {

    const item = this.itemRepo.create({ ...dto, user: { id: user.userId } });
    return this.itemRepo.save(item);
  }

  async getItemsForUser(userId: number) {
    return this.itemRepo.find({
      where: { user: { id: userId } },
    });
  }

  async deleteItem(itemId: number, userId: number): Promise<boolean> {
    const item = await this.itemRepo.findOne({
      where: { id: itemId, user: { id: userId } },
    });

    if (!item) return false;

    await this.itemRepo.remove(item);
    return true;
  }

  async updateItem(id: number, dto: CreateItemDto, userId: number) {
    const item = await this.itemRepo.findOne({ where: { id, user: { id: userId } } });
    if (!item) throw new Error('Item não encontrado');
    Object.assign(item, dto);
    return this.itemRepo.save(item);
  }
}
