import { Entity, PrimaryGeneratedColumn, Column, ManyToOne } from 'typeorm';
import { User } from '../auth/user.entity';

@Entity('items')
export class Item {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  nome: string;

  @Column()
  categoria: string;

  @Column('decimal', { precision: 10, scale: 2 })
  preco: number;

  @Column()
  quantidade: number;

  @Column()
  codigo: string;

  @Column()
  unidade: string;

  @Column({ nullable: true })
  valorUnidade: string;

  @ManyToOne(() => User, user => user.items)
  user: User;
}
