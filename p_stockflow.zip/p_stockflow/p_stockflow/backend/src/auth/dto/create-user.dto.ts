export class CreateUserDto {
    nome: string;
    email: string;
    password: string;
    contacto: string;
  }
  