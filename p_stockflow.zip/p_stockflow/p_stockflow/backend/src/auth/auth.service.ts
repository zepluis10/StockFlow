import { Injectable, ConflictException, UnauthorizedException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, MoreThan } from 'typeorm';
import { User } from './user.entity';
import { CreateUserDto } from './dto/create-user.dto';
import * as bcrypt from 'bcrypt';
import { LoginDto } from './dto/login.dto';
import { JwtService } from '@nestjs/jwt';
import { EmailService } from './email.service';

@Injectable()
export class AuthService {
  constructor(
    @InjectRepository(User)
    private readonly userRepo: Repository<User>,
    private readonly jwtService: JwtService,
    private readonly emailService: EmailService
  ) { }

  async sendVerificationCode(email: string) {

    const code = Math.floor(100000 + Math.random() * 900000).toString();
    const expires = new Date(Date.now() + 10 * 60 * 1000);

    const userExists = await this.userRepo.findOne({ where: { email } });
    if (userExists) {
      throw new ConflictException('Email já está em uso');
    }

    let tempUser = await this.userRepo.findOne({ where: { email } });
    if (!tempUser) {
      tempUser = this.userRepo.create({
        email,
        nome: '',
        password: '',
        contacto: '',
        recoveryCode: code,
        recoveryCodeExpires: expires,
      });
    } else {
      tempUser.recoveryCode = code;
      tempUser.recoveryCodeExpires = expires;
    }
    await this.userRepo.save(tempUser);

    await this.emailService.sendMail(
      email,
      'Código de verificação StockFlow',
      `O teu código de verificação é: ${code}\nÉ válido por 10 minutos.`
    );
    return { message: 'Código de verificação enviado para o email.' };
  }

  async register(dto: CreateUserDto & { code: string }) {
    const tempUser = await this.userRepo.findOne({
      where: {
        email: dto.email,
        recoveryCode: dto.code,
        recoveryCodeExpires: MoreThan(new Date()),
      },
    });

    if (!tempUser) {
      throw new UnauthorizedException('Código de verificação inválido ou expirado.');
    }

    const userExists = await this.userRepo.findOne({ where: { email: dto.email, password: MoreThan('') } });
    if (userExists) {
      throw new ConflictException('Email já está em uso');
    }

    tempUser.nome = dto.nome;
    tempUser.contacto = dto.contacto;
    tempUser.password = await bcrypt.hash(dto.password, 10);
    tempUser.recoveryCode = null;
    tempUser.recoveryCodeExpires = null;
    await this.userRepo.save(tempUser);

    await this.emailService.sendMail(
      dto.email,
      'Bem-vindo!',
      'Obrigado por te registares!'
    );

    return { message: 'Utilizador registado com sucesso' };
  }

  async login(dto: LoginDto) {
    const user = await this.userRepo.findOne({ where: { email: dto.email } });

    if (!user) {
      throw new UnauthorizedException('Email ou palavra-passe inválidos.');
    }

    const isMatch = await bcrypt.compare(dto.password, user.password);
    if (!isMatch) {
      throw new UnauthorizedException('Email ou palavra-passe inválidos.');
    }

    const payload = { sub: user.id, email: user.email, nome: user.nome, contacto: user.contacto };
    const token = this.jwtService.sign(payload);

    return {
      message: 'Login realizado com sucesso',
      access_token: token,
    };
  }

  async recoverPassword(email: string) {
    const user = await this.userRepo.findOne({ where: { email } });
    if (!user) {
      throw new Error('Utilizador não encontrado.');
    }

    const codigo = Math.floor(100000 + Math.random() * 900000).toString();
    const validade = new Date(Date.now() + 10 * 60 * 1000);

    user.recoveryCode = codigo;
    user.recoveryCodeExpires = validade;
    await this.userRepo.save(user);

    await this.emailService.sendMail(
      email,
      'Recuperação de Palavra-passe',
      `O teu código de recuperação é: ${codigo}\nÉ válido por 10 minutos.`
    );
    return { message: 'Email de recuperação enviado.' };
  }

  async validateRecoveryCode(email: string, code: string) {
    const user = await this.userRepo.findOne({ where: { email } });
    if (
      !user ||
      !user.recoveryCode ||
      user.recoveryCode !== code ||
      !user.recoveryCodeExpires ||
      user.recoveryCodeExpires < new Date()
    ) {
      throw new BadRequestException('Código inválido ou expirado.');
    }

    return { message: 'Código válido.' };
  }

  async changePassword(email: string, newPassword: string, code: string) {
    const user = await this.userRepo.findOne({ where: { email } });
    if (!user) throw new Error('Utilizador não encontrado.');
    if (
      !user.recoveryCode ||
      user.recoveryCode !== code ||
      !user.recoveryCodeExpires ||
      user.recoveryCodeExpires < new Date()
    ) {
      throw new Error('Código inválido ou expirado.');
    }
    user.password = await bcrypt.hash(newPassword, 10);
    user.recoveryCode = null;
    user.recoveryCodeExpires = null;
    await this.userRepo.save(user);
    return { message: 'Palavra-passe alterada com sucesso.' };
  }
}

