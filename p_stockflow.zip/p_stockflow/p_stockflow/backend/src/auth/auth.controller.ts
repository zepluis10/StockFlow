import { Body, Controller, Post } from '@nestjs/common';
import { AuthService } from './auth.service';
import { CreateUserDto } from './dto/create-user.dto';
import { LoginDto } from './dto/login.dto';
import { UnauthorizedException } from '@nestjs/common';

@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) { }

  @Post('send-verification-code')
  async sendVerificationCode(@Body('email') email: string) {
    return this.authService.sendVerificationCode(email);
  }

  @Post('register')
  register(@Body() dto: CreateUserDto & { code: string }) {
    return this.authService.register(dto);
  }

  @Post('login')
  login(@Body() dto: LoginDto) {
    return this.authService.login(dto);
  }

  @Post('recover-password')
  async recoverPassword(@Body('email') email: string) {
    return this.authService.recoverPassword(email);
  }

  @Post('validate-recovery-code')
  async validateRecoveryCode(
    @Body('email') email: string,
    @Body('code') code: string,
  ) {
    return this.authService.validateRecoveryCode(email, code);
  }

  @Post('change-password')
  async changePassword(@Body() body: { email: string, password: string, code: string }) {
    return this.authService.changePassword(body.email, body.password, body.code);
  }
}
