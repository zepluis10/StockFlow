import { Injectable } from '@nestjs/common';
import * as nodemailer from 'nodemailer';

@Injectable()
export class EmailService {
  private transporter;

  constructor() {
    this.transporter = nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: 587,
      secure: false,
      auth: {
        user: 'zepluis10@gmail.com',
        pass: 'byrj qkbd awnc qivr',
      },
    });
  }

  async sendMail(to: string, subject: string, text: string) {
    const mailOptions = {
      from: '"StockFlow" <zepluis10@gmail.com>',
      to,
      subject,
      text,
    };

    return this.transporter.sendMail(mailOptions);
  }
}