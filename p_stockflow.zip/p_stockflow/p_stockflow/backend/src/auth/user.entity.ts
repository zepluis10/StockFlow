import { Entity, Column, PrimaryGeneratedColumn, OneToMany } from 'typeorm';
import { Item } from '../items/item.entity';
import { Cliente } from '../clientes/cliente.entity';

@Entity('users')
export class User {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  nome: string;

  @Column({ unique: true })
  email: string;

  @Column()
  password: string;

  @Column()
  contacto: string;

  @Column({ type: 'varchar', nullable: true })
  recoveryCode?: string | null;

  @Column({ type: 'datetime', nullable: true })
  recoveryCodeExpires?: Date | null;

  @Column({ type: 'varchar', nullable: true })
  avatarUrl?: string | null;

  @OneToMany(() => Item, item => item.user)
  items: Item[];

  @OneToMany(() => Cliente, cliente => cliente.user)
  clientes: Cliente[];
}
