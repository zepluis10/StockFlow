import {
  Controller,
  Post,
  Body,
  UseGuards,
  Request,
  Get,
  Delete,
  Param,
  NotFoundException,
  Put,
} from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { ClienteService } from './cliente.service';
import { CreateClienteDto } from './dto/create-cliente.dto';

@Controller('clientes')
@UseGuards(AuthGuard('jwt'))
export class ClienteController {
  constructor(private readonly clienteService: ClienteService) { }

  @Post()
  addCliente(@Body() dto: CreateClienteDto, @Request() req) {
    return this.clienteService.addCliente(dto, req.user);
  }

  @Get()
  getUserClientes(@Request() req) {
    return this.clienteService.getClientesForUser(req.user.userId);
  }

  @Delete(':id')
  async deleteCliente(@Param('id') id: number, @Request() req) {
    const deleted = await this.clienteService.deleteCliente(id, req.user.userId);
    if (!deleted) {
      throw new NotFoundException('Cliente não encontrado ou não pertence a este utilizador.');
    }
    return { message: 'Cliente apagado com sucesso.' };
  }

  @Put(':id')
  async updateCliente(@Param('id') id: number, @Body() dto: CreateClienteDto, @Request() req) {
    return this.clienteService.updateCliente(id, dto, req.user.userId);
  }
}