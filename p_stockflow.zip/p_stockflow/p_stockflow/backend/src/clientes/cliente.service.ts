import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Cliente } from './cliente.entity';
import { CreateClienteDto } from './dto/create-cliente.dto';

@Injectable()
export class ClienteService {
  constructor(
    @InjectRepository(Cliente)
    private readonly clienteRepo: Repository<Cliente>,
  ) { }

  async addCliente(dto: CreateClienteDto, user: any) {
    const cliente = this.clienteRepo.create({ ...dto, user: { id: user.userId } });
    return this.clienteRepo.save(cliente);
  }

  async getClientesForUser(userId: number) {
    return this.clienteRepo.find({
      where: { user: { id: userId } },
    });
  }

  async deleteCliente(clienteId: number, userId: number): Promise<boolean> {
    const cliente = await this.clienteRepo.findOne({
      where: { id: clienteId, user: { id: userId } },
    });

    if (!cliente) return false;

    await this.clienteRepo.remove(cliente);
    return true;
  }

  async updateCliente(id: number, dto: CreateClienteDto, userId: number) {
    const cliente = await this.clienteRepo.findOne({ where: { id, user: { id: userId } } });
    if (!cliente) throw new Error('Cliente não encontrado');
    Object.assign(cliente, dto);
    return this.clienteRepo.save(cliente);
  }
}