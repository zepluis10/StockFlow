export class CreateClienteDto {
  nome: string;
  email: string;
  telefone: string;
  localidade: string;
}