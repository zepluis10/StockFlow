import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { NestExpressApplication } from '@nestjs/platform-express';
import { join } from 'path';

async function bootstrap() {
  const app = await NestFactory.create<NestExpressApplication>(AppModule);
  app.enableCors();
  app.useStaticAssets(join(__dirname, '..', 'uploads'), { prefix: '/uploads/' });

  app.use((req, res, next) => {
    if (req.url.includes('/profile/avatar')) {
      console.log('=== REQUEST TO /profile/avatar ===');
      console.log('Method:', req.method);
      console.log('Headers:', req.headers);
      console.log('Content-Type:', req.headers['content-type']);
      console.log('Authorization:', req.headers.authorization ? 'Present' : 'Missing');
    }
    next();
  });

  await app.listen(3001);
}
bootstrap();
